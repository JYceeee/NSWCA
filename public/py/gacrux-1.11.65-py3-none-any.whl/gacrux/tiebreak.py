# -*- coding: utf-8 -*-
"""
Created on Fri Aug  11 11:43:23 2023
@author: Otto Milvang, sjakk@milvang.no
"""
import math
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime

if __name__[:7] == "gacrux." or __package__ is not None and __package__ == "gacrux":
    from gacrux import chessjson 
    from gacrux import rating
    from gacrux.gacruxexeptions import GacruxInputError
else:
    import chessjson 
    import rating
    from gacruxexeptions import GacruxInputError


"""
Structure

+--- tiebreaks: [  - added in compute-tiebreak
|         {
|             order: priority of tiebreak
|             name: Acronym from regulations
|             pointtype: mpoints (match points) gpoints (game points) or points
|             modifiers: { low / high / lim / urd / predetermined / foremode / rev / ver / vuv / rev }
|         },
|         ...
|
|       ]
+--- isteam: True/False
+--- currentRound: Standings after round 'currentround'
+--- rounds: Total number of rounds
+--- rr: RoundRobin (True/False)
+--- scoresystem: {
|        game: { W:1.0, D:0.5, L:0.0, Z:0.0, P:1.0, A:0.5, U: 0.0 }
|        team: { W:1.0, D:1.0, L:0.0, Z:0.0, P:1.0, A:1.0, U: 0.0 }
|                 }
+--- players/teams:  {
|              1: {
|                    cid: startno
|                    rating: rating
|                    kfactor: k
|                    rating: rating
|                    rrst: {  - results, games for players, matches for teams
|                        1: {  - round
|                              points - points for game / match
|                              rpoints - for games, points with score system 1.0 / 0.5 / 0.0
|                              color - w / b
|                              played  - boolean
|                              rated - boolean
|                              opponent - id of opponent
|                              opprating - rating of opponent
|                              deltaR - for rating change
|                            }
|                        2: {  - round 2 }
|                           ...
|                           }
|                   tbval: {  - intermediate results from tb calculations }
|     ---- output for each player / team
|                   score: [ array of tiebreaks values, same order and length as 'tiebreaks'
|                   rank: final rank of player / team
|                 },
|              2: { ... },
|                  ...
|         }
+--- rankorder: [ array of rankorder,  players/teams ]
|

"""


class tiebreak:

    # CURRENT_RULES = 1  => First implementation
    # CURRENT_RULES = 2  => 2026-02-01,  §16, max value  
    
    TIEBREAK_RULES = {
        0 : "2022-01-01",
        1 : "2024-08-01",
        2 : "2026-03-01",   # Approved by FIDE Council on 02/02/2026
        } 

    # The format TIEBREAK_RULES states its dates in, and the one a tournament's start
    # date is read in, so that find_tmversion() compares two dates and not two strings.
    ISO_DATE = "%Y-%m-%d"

    # constructor function
    def __init__(self, tournament, currentround, params):
        self.tiebreaklist = {
            "NUL":   {"name": "NUL",   "func": self.get_nul,                             "rev": False, "flag": ""   ,"desc": "Null"},
            "PTS":   {"name": "PTS",   "func": self.compute_pts,                         "rev": True , "flag": ""   ,"desc": "Points (default)"},
            "MPTS":  {"name": "PTS",   "func": self.compute_pts,                         "rev": True , "flag": ""   ,"desc": "Match Points"},
            "GPTS":  {"name": "PTS",   "func": self.compute_pts,                         "rev": True , "flag": ""   ,"desc": "Game Points"},
            "SNO":   {"name": "SNO",   "func": self.get_builtin,                         "rev": False, "flag": ""   ,"desc": "Start number"},
            "TPN":   {"name": "SNO",   "func": self.get_builtin,                         "rev": False, "flag": ""   ,"desc": "Start number"},
            "RANK":  {"name": "RANK",  "func": self.get_builtin,                         "rev": False, "flag": ""   ,"desc": "Original rank in tournament file"},
            "WIN":   {"name": "WIN",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Number of Wins"},
            "WON":   {"name": "WON",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Number of Games Won"},
            "BPG":   {"name": "BPG",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Number of Games Played with Black"},
            "BWG":   {"name": "BWG",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Number of Games Won with Black"},
            "GE":    {"name": "GE",    "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Same as REP"},
            "REP":   {"name": "REP",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Rounds one Elected to Play"},
            "RIP":   {"name": "RIP",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "number of rounds paired (for TPN assignment)"},
            "VUR":   {"name": "VUR",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Voluntary unplayed rounds"},
            "NUM":   {"name": "NUM",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Number of played games"},
            "xxCOP": {"name": "COP",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Color preference"}, # depricated, moved to crosstable
            "COD":   {"name": "COD",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Color difference"},
            "CSQ":   {"name": "CSQ",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Color sequence"},
            "RTG":   {"name": "RTG",   "func": self.get_builtin,                         "rev": True , "flag": ""   ,"desc": "Start rating"},
            "MPVGP": {"name": "MPVGP", "func": self.reverse_pointtype,                   "rev": True , "flag": ""   ,"desc": "Match Points or Game Points"},
            "DE":    {"name": "DE",    "func": self.compute_direct_encounter,            "rev": False, "flag": "P"  ,"desc": "Direct Encounter"},
            "EDE":   {"name": "EDE",   "func": self.compute_ext_direct_encounter,        "rev": False, "flag": ""   ,"desc": "Direct Encounter"},
            "EDEC":  {"name": "EDEC",  "func": self.compute_ext_direct_encounter,        "rev": False, "flag": ""   ,"desc": "Direct Encounter"},
            "EDET":  {"name": "EDET",  "func": self.compute_ext_direct_encounter,        "rev": False, "flag": ""   ,"desc": "Direct Encounter"},
            "EDEB":  {"name": "EDEB",  "func": self.compute_ext_direct_encounter,        "rev": False, "flag": ""   ,"desc": "Direct Encounter"},
            "EDEBT": {"name": "EDEBT", "func": self.compute_ext_direct_encounter,        "rev": False, "flag": ""   ,"desc": "Direct Encounter"},
            "EDEBB": {"name": "EDEBB", "func": self.compute_ext_direct_encounter,        "rev": False, "flag": ""   ,"desc": "Direct Encounter"},
            "PS":    {"name": "PS",    "func": self.compute_progressive_score,           "rev": True , "flag": "C"  ,"desc": "Progressive Scores"},
            "KS":    {"name": "KS",    "func": self.compute_koya,                        "rev": True , "flag": "L"  ,"desc": "Koya system"},
            "BH":    {"name": "BH",    "func": self.compute_buchholz_sonneborn_berger,   "rev": True , "flag": "M"  ,"desc": "Bochholz"},
            "FB":    {"name": "FB",    "func": self.compute_buchholz_sonneborn_berger,   "rev": True , "flag": "M"  ,"desc": "Fore Bochholz"},
            "SB":    {"name": "SB",    "func": self.compute_buchholz_sonneborn_berger,   "rev": True , "flag": "C"  ,"desc": "Sonneborn Berger"},
            "ABH":   {"name": "ABH",   "func": self.compute_buchholz_sonneborn_berger,   "rev": True , "flag": ""   ,"desc": "Adjusted score for Buchholz"},
            "AFB":   {"name": "AFB",   "func": self.compute_buchholz_sonneborn_berger,   "rev": True , "flag": ""   ,"desc": "Adjusted score for Fore Buchholz"},
            "AOB":   {"name": "AOB",   "func": self.compute_average_of_buchholz,         "rev": True , "flag": "F"  ,"desc": "Average of Buchholz"},
            "RTNG":  {"name": "RTNG",  "func": self.compute_rtng,                        "rev": True , "flag": "U"  ,"desc": "Adj rating"},
            "ARO":   {"name": "ARO",   "func": self.compute_ratingperformance,           "rev": True , "flag": "MU" ,"desc": "Average Rating of opponents"},
            "TPR":   {"name": "TPR",   "func": self.compute_ratingperformance,           "rev": True , "flag": "U"  ,"desc": "Tournament Rating Performance"},
            "PTP":   {"name": "PTP",   "func": self.compute_ratingperformance,           "rev": True , "flag": "U"  ,"desc": "Perfect Rating Performance"},
            "RSES":  {"name": "RSES",  "func": self.compute_ratingperformance,           "rev": True , "flag": "U"  ,"desc": "Rating Sum Expected Score"},
            "APRO":  {"name": "APRO",  "func": self.compute_average_rating_performance,  "rev": True , "flag": "U"  ,"desc": "Average of Rating Performance"},
            "APPO":  {"name": "APPO",  "func": self.compute_average_perfect_performance, "rev": True , "flag": "U"  ,"desc": "Average of Perfect Performance"},
            "ESB":   {"name": "ESB",   "func": self.compute_ext_sonneborn_berger,        "rev": True , "flag": "CP" ,"desc": "Extended Sonneborn Berger" },
            "EMMSB": {"name": "EMMSB", "func": self.compute_ext_sonneborn_berger,        "rev": True , "flag": "CP" ,"desc": "Extended Sonneborn Berger" },
            "EMGSB": {"name": "EMGSB", "func": self.compute_ext_sonneborn_berger,        "rev": True , "flag": "CP" ,"desc": "Extended Sonneborn Berger" },
            "EGMSB": {"name": "EGMSB", "func": self.compute_ext_sonneborn_berger,        "rev": True , "flag": "CP" ,"desc": "Extended Sonneborn Berger" },
            "EGGSB": {"name": "EGGSB", "func": self.compute_ext_sonneborn_berger,        "rev": True , "flag": "CP" ,"desc": "Extended Sonneborn Berger" },
            "BC":    {"name": "BC",    "func": self.compute_boardcount,                  "rev": False, "flag": ""   ,"desc": "Board count"},
            "TBR":   {"name": "TBR",   "func": self.compute_top_bottom_board,            "rev": False, "flag": ""   ,"desc": "Board count"},
            "BBE":   {"name": "BBE",   "func": self.compute_top_bottom_board,            "rev": False, "flag": ""   ,"desc": "Board count"},
            "SSSC":  {"name": "SSSC",  "func": self.compute_score_strength_combination,  "rev": True , "flag": "PKF","desc": "Score strength combination"},
            "STD":   {"name": "STD",   "func": self.compute_std,                         "rev": True , "flag": ""   ,"desc": "Stanard score system"},
            "ACC":   {"name": "ACC",   "func": self.compute_acc,                         "rev": True , "flag": ""   ,"desc": "Points + accellerated points"},
            "FLT":   {"name": "FLT",   "func": self.compute_flt_dutch,                   "rev": True , "flag": ""   ,"desc": "Float (8=df 4=uf in prev round, 2=df 1=uf in 2 rounds before)"},
            "FLTD":  {"name": "FLT",   "func": self.compute_flt_dutch,                   "rev": True , "flag": ""   ,"desc": "Float (8=df 4=uf in prev round, 2=df 1=uf in 2 rounds before)"},
            "FLTFT": {"name": "FLT",   "func": self.compute_flt_team,                    "rev": True , "flag": ""   ,"desc": "Float (2=df 1=uf in 2 rounds before)"},
            "RFP":   {"name": "RFP",   "func": self.compute_rfp,                         "rev": True , "flag": ""   ,"desc": "Registered for round"},
            "TOP":   {"name": "TOP",   "func": self.compute_top,                         "rev": True , "flag": ""   ,"desc": "Is player a top-scorer in last round"},
            "RND":   {"name": "RND",   "func": self.compute_random,                      "rev": False, "flag": ""   ,"desc": "Unique random number"},
            }

        self.chj = chessevent = chessjson.chessjson()    
        self.tournament = tournament
        self.tiebreaks = []
        if tournament is None:
            return
        # Set pre-determined or swiss
        if params is not None:
            params["is_rr"] = None
            if params.get("pre_determined", False):
                params["is_rr"] = True
            if params.get("swiss", False):
                params["is_rr"] = False

        self.isteam = self.isteam = tournament["teamTournament"] if "teamTournament" in tournament else False
        self.teamsize = tournament["teamSize"] if "teamSize" in tournament else 1
        chessevent.update_tournament_random(tournament, self.isteam)
        self.rounds = max(tournament.get("numRounds", 0), tournament.get("currentRound", 0))
        self.currentround = currentround if currentround >= 0 else self.rounds
        self.maxboard = 0
        self.lastplayedround = 0
        self.primaryscore = None  # use default
        declared_primary = tournament["scoreSystem"].get("primary") if self.isteam else None
        if declared_primary is not None:
            self.set_primaryscore(declared_primary)
        self.accelerated = tournament["accelerated"] if "accelerated" in tournament else None
        # Every result a game can carry has to resolve to a number here: get_score
        # returns a letter it cannot look up, and the caller subtracts it. The
        # unplayed results all score as Z, which is what A and U already did --
        # F, H and P are the three record 299 can write that were missing.
        self.rating = {"W": Decimal("1.0"), "D": Decimal("0.5"), "L": "Z", "Z": Decimal("0.0"),
                       "A": "Z", "U": "Z", "F": "Z", "H": "Z", "P": "Z"}

        if self.isteam:
            self.scoresystem = tournament["scoreSystem"]
            self.matchscore = tournament["scoreSystem"]["match"]
            self.gamescore = tournament["scoreSystem"]["game"]
            [self.cplayers, self.cteam] = chessevent.build_tournament_teamcompetitors(tournament)
            self.allgames = chessevent.build_all_games(tournament, self.cteam, False)
            self.cgames = chessevent.build_games_from_id(tournament)
            self.teams = self.prepare_competitors(tournament, "match")
            self.compute_score(self.teams, "match", "mpoints", self.matchscore, self.currentround)
            self.compute_score(self.teams, "game", "gpoints", self.gamescore, self.currentround)
        else:
            self.matchscore = tournament["scoreSystem"]["game"]
            self.gamescore = tournament["scoreSystem"]["game"]
            self.players = self.prepare_competitors(tournament, "game")
            self.compute_score(self.players, "game", "points", self.gamescore, self.currentround)
        self.cmps = self.teams if self.isteam else self.players
        numcomp = len(self.cmps)
        self.rankorder = list(self.cmps.values())

        # find tournament type
        tt = tournament["tournamentType"].upper()
        self.rr = params["is_rr"] if params is not None and "is_rr" in params else False
        if self.rr is None:
            if tt.find("SWISS") >= 0:
                self.rr = False
            elif tt.find("RR") >= 0 or tt.find("ROBIN") >= 0 or tt.find("BERGER") >= 0:
                self.rr = True
            elif numcomp == self.rounds + 1 or numcomp == self.rounds:
                self.rr = True
            elif numcomp * 2 == (self.rounds + 1) or numcomp * 2 == self.rounds:
                self.rr = True
        self.unrated = int(params["unrated"]) if params is not None and "unrated" in params and params["unrated"] is not None else None
        self. rulesversion = max(self.TIEBREAK_RULES.keys())

    def get_startdate(self, tm):
        """The tournament's start date as a date, or None when the file gives no usable one.

        The date is read, not measured. The leading ten characters are parsed as an ISO
        "YYYY-MM-DD" and whatever follows them is discarded - the field padding of a
        fixed-width TRF, a time of day, the rest of a timestamp - because none of it
        changes the day the tournament started. Returning a date rather than the string it
        was written as is what stops a longer spelling of the same day from choosing a
        different rule set than the short one.

        None is returned for an absent record, for a JSON null (len() raised TypeError on
        it) and for anything that is not an ISO date, because a date the engine cannot
        read is one it must not guess at.
        """
        startdate = tm.get("tournamentInfo", {}).get("startDate", None)
        if not isinstance(startdate, str):
            return None
        try:
            return datetime.strptime(startdate[0:10], self.ISO_DATE).date()
        except ValueError:
            return None

    def find_tmversion(self, tm):
        """Select the tie-break rules that apply to this tournament, by its start date.

        A rule set applies from the day it came into force, so a tournament that started
        before the 2026 rules did is scored under the previous set. Both sides of the
        comparison are dates, so no spelling of a date can decide it.
        """
        startdate = self.get_startdate(tm)
        if startdate is None:
            # No usable start date: the tournament cannot be placed on either side of the
            # cut-off, so it takes the newest rule set - the rules in force - as a stated
            # and deterministic fallback.
            #
            # It does not fall back on today's date, which is what used to happen. That
            # was datetime.now(), the local clock, so an undated file scored its
            # tie-breaks one way before local midnight and another way after it, and two
            # machines in different time zones disagreed about the same file.
            #
            # Refusing an undated file was considered instead and rejected: such files are
            # ordinary and score correctly, so refusing them would reject working input to
            # fix a defect they do not have.
            self.rulesversion = max(self.TIEBREAK_RULES.keys())
            return
        cutoff = datetime.strptime(self.TIEBREAK_RULES[2], self.ISO_DATE).date()
        self.rulesversion = 1 if startdate < cutoff else max(self.TIEBREAK_RULES.keys())

    def zero(self, scorename):
        return self.matchscore["Z"] if scorename == "match" else self.gamescore["Z"]

    # get_score
    # return a float value from result struct and color

    def set_primaryscore(self, scorename):
        if self.primaryscore is not None:
            return
        scorename = scorename.lower()
        if scorename == "mp" or scorename == "match":
            self.primaryscore = "mpoints"
        elif scorename == "gp" or scorename == "game":
            self.primaryscore = "gpoints"
        else:
            self.primaryscore = "points"

    def get_scorex(self, slist, result, color):
        res = self.get_scorex(slist, result, color)
        #print("getscore:", slist)
        #print(result)
        #print(color)
        #print(res)
        #print()
        return res

    def get_score(self, slist, result, color):    
        if color not in result:
            return Decimal("0.0")
        if "score" in result[color]:
            return result[color]["score"]

        res = self.chj.get_result_res(result, color, default=None)
        if res is None and self.chj.get_result_cid(result, color) > 0:
            ores = {"white": "black", "black": "white"}[color]
            res = self.chj.reverse.get(self.chj.get_result_res(result, ores, default=None))
        if res is None:
            # print("get_score" ,  slist, result, color, "Null")
            return Decimal("0.0")
        while res in slist:
            if res == "L" and result["played"] is False:
                res = "Z"
            res = slist[res]
        # print("get_score" ,  slist, result, color, res)
        return res

    def is_vur(self, result, color):  #
        if result["played"]:
            return False
        res = self.chj.get_result_res(result, color, default=None)
        if res is None and self.chj.get_result_cid(result, color) > 0:
            ores = {"white": "black", "black": "white"}[color]
            res = self.chj.reverse.get(self.chj.get_result_res(result, ores, default=None))
        if res is None:
            # print("get_score" ,  slist, result, color, "Null")
            return True
        # if res == 'W' and result['black'] > 0:  // Full point bye is not vur
        if res == "W":
            return False
        return True

    """
    compute_tiebreaks(self, chessfile, tournamentno, params)
    chessfile - Chessfile structure
    tournamentno - which tournament to calculate
    params - Parameters from core
    """

    def compute_tiebreaks(self, tournament, params):
        # run tiebreak
        tm = tournament
        self.find_tmversion(tm)
        tblist = params["tiebreak"]
        if len(tblist) == 0 and "rankOrder" in tm:
            tblist = tm["rankOrder"]
            params["tiebreak"] = tblist
        for pos in range(0, len(tblist)):
            mytb = self.parse_tiebreak(pos + 1, tblist[pos])
            self.compute_single_tiebreak(mytb)
        
        tm["rankOrder"] = self.tiebreaks
        correct = True
        competitors = []
        for cmp in tm["competitors"]:
            startno = cmp["cid"]
            rank = cmp["rank"] = self.cmps[startno]["rank"]
            tbs = cmp["tiebreakScore"] = self.cmps[startno]["tiebreakScore"]
            competitor = {
                "cid": startno,
                "rank" : rank,
                "tiebreakScore" : tbs,
            }
            if params["check"]: 
                competitor["tiebreakDetails"] = self.cmps[startno]["tiebreakDetails"]
                if self.isteam:
                    competitor["boardPoints"] = self.cmps[startno]["tbval"]["gpoints_" + "bp"]
            correct = correct and cmp["rank"] == self.cmps[startno]["orgrank"]
            competitors.append(competitor)
        result = {
            "rules": self.TIEBREAK_RULES[self.rulesversion],
            "round": self.rounds, 
            "tiebreaks": self.tiebreaks, 
            "competitors": competitors
        }
        if params["check"]:
             result["check"] = correct
        return result 
        
    def compute_single_tiebreak(self, tb):
        cmps = self.cmps
        tbname = tb["name"] 
        tiebreak = self.tiebreaklist[tbname] if tbname in self.tiebreaklist else self.tiebreaklist["NUL"]        
        tb["modifiers"]["rev"] = tb["modifiers"]["rev"] ^ tiebreak["rev"]
        tbname = tiebreak["func"](tb, cmps, self.currentround)
        
        self.tiebreaks.append(tb)
        index = len(self.tiebreaks) - 1
        self.addval(cmps, tb, tbname)
        rev = "rev" in tb["modifiers"] and not tb["modifiers"]["rev"]
        reverse = 1 if rev else -1
        self.rankorder = sorted(self.rankorder, key=lambda cmp: (\
            cmp["rank"], \
            (cmp["tiebreakScore"][index] is None) ^ rev, \
            cmp["tiebreakScore"][index] * reverse if cmp["tiebreakScore"][index] is not None else 0, \
            cmp["cid"]))
        rank = 1
        val = self.rankorder[0]["tiebreakScore"][index]
        for i in range(1, len(self.rankorder)):
            rank += 1
            if self.rankorder[i]["rank"] == rank or self.rankorder[i]["tiebreakScore"][index] != val:
                self.rankorder[i]["rank"] = rank
                val = self.rankorder[i]["tiebreakScore"][index]
            else:
                self.rankorder[i]["rank"] = self.rankorder[i - 1]["rank"]


    def prepare_competitors(self, tournament, scorename):
        rounds = self.currentround
        ptype = "mpoints" if self.isteam else "points"
        cmps = {}
        for competitor in tournament["competitors"]:
            rnd = competitor["random"] if "random" in competitor else 0
            cmp = {
                "cid": competitor["cid"],
                "rsts": {},
                "orgrank": competitor["rank"] if "rank" in competitor else 0,
                "rank": 1,
                "rating": (competitor["rating"]["rating"] if "rating" in competitor and competitor["rating"] is not None else None),
                "present": competitor["present"] if "present" in competitor else True,
                "tiebreakScore": [],
                "tiebreakDetails": [],
                "rnd": rnd,
                "adjust": competitor["adjust"] if "adjust" in competitor else [],
                "tbval": {},
            }
            # Be sure that missing results are replaced by zero
            for rnd in range(1, rounds + 1):
                cmp["rsts"][rnd] = {
                    ptype: self.zero(scorename),
                    "rpoints": Decimal("0.0"),
                    "res": "Z",
                    "color": "w",
                    "played": False,
                    "vur": True,
                    "rated": False,
                    "opponent": 0,
                    "opprating": None,
                    "board": 0,
                    "deltaR": 0,
                }
            cmps[competitor["cid"]] = cmp
        for rst in tournament[scorename + "List"]:
            if rst["round"] <= self.currentround or True:
                self.prepare_result(cmps, rst, self.matchscore)
                if self.isteam:
                    self.prepare_teamgames(cmps, rst, self.scoresystem)

        # helpers.json_output('c:\\temp\\mc02.txt', cmps)

        return cmps

    def solve_score(self, tournament, score, scorename, scoretype):
        points = score[scorename][scoretype]
        if isinstance(points, Decimal):
            return points
        if len(points) == 2 and points[1] == "*":
            return self.solve_score(tournament, score, "game", points[0]) * tournament["teamSize"]
        return self.solve_score(tournament, score, scorename, points)

    def prepare_result(self, cmps, rst, scoresystem):
        ptype = "mpoints" if self.isteam else "points"
        scoresystem = self.matchscore if self.isteam else self.gamescore
        rnd = rst["round"]
        white = self.chj.get_result_cid(rst, "white")
        wPoints = self.get_score(scoresystem, rst, "white")
        wrPoints = self.get_score(self.rating, rst, "white")
        if ptype in rst:
            wPoints = rst[ptype]
        wVur = self.is_vur(rst, "white")
        wrating = None
        brating = None
        expscore = None
        black = self.chj.get_result_cid(rst, "black")
        if black > 0:
            if "result" not in rst["black"]:
                err = "No result for black in round " +  str(rst.get("round", 0)) + ", white=" +  str(white) + ", black=" +  str(black)
                raise GacruxInputError(err)
            bPoints = self.get_score(scoresystem, rst, "black")
            brPoints = self.get_score(self.rating, rst, "black")
            if ptype in rst:
                bPoints = rst[ptype]
            bVur = self.is_vur(rst, "black")
            if rst["played"]:
                if cmps.get(white, {}).get("rating", None) is not None:
                    wrating = cmps[white]["rating"]
                if cmps.get(black, {}).get("rating", None) is not None:
                    brating = cmps[black]["rating"]
                expscore = rating.ComputeExpectedScore(wrating, brating)
        board = rst["board"] if "board" in rst else 0
        if white > 0:
            cmps[white]["rsts"][rnd] = {
                ptype: wPoints,
                "rpoints": wrPoints,
                "res": self.chj.get_result_res(rst, "white"),
                "color": "w",
                "played": rst["played"],
                "vur": wVur,
                "rated": rst["rated"] if "rated" in rst else (rst["played"] and black > 0),
                "opponent": black,
                "opprating": brating,
                "board": board,
                "deltaR": (rating.ComputeDeltaR(expscore, wrPoints) if expscore is not None else None),
                "games": rst["games"] if "games" in rst else None,
            }
        if black > 0:
            self.lastplayedround = max(self.lastplayedround, rnd)
            cmps[black]["rsts"][rnd] = {
                ptype: bPoints,
                "rpoints": brPoints,
                "res": self.chj.get_result_res(rst, "black"),
                "color": "b",
                "played": rst["played"],
                "vur": bVur,
                "rated": rst["rated"] if "rated" in rst else (rst["played"] and white > 0),
                "opponent": white,
                "opprating": wrating,
                "board": board,
                "deltaR": (rating.ComputeDeltaR(Decimal(1.0) - expscore, brPoints) if expscore is not None else None),
                "games": rst["games"] if "games" in rst else None,
            }
        return

    def prepare_teamgames(self, cmps, rst, score):
        maxboard = 0
        chj = self.chj
        rnd = rst["round"]
        for col in ["white", "black"]:
            if col in rst and (competitor := chj.get_result_cid(rst, col)) > 0:
                gpoints = Decimal("0")
                games = []
                tmatch = cmps[competitor]["rsts"][rnd]
 
                if len(tmatch["games"]) > 0 and chj.get_result_cid(rst, "black") > 0:
                    for game in [self.cgames[game] for game in tmatch["games"]]:
                        white = chj.get_result_cid(game, "white")
                        black = chj.get_result_cid(game, "black")
                        board = game["board"] if "board" in game else 0
                        maxboard = max(maxboard, board)
                        wVur = self.is_vur(game, "white")
                        if self.cteam[white] == competitor and board > 0:
                            points = self.get_score(self.gamescore, game, "white")
                            gpoints += points
                            games.append(
                                {
                                    "points": points,
                                    "rpoints": self.get_score(self.rating, game, "white"),
                                    "color": "w",
                                    "vur": wVur,
                                    "played": game["played"],
                                    "rated": game["rated"] if "rated" in rst else (game["played"] and black > 0),
                                    "player": white,
                                    "opponent": black,
                                    "board": board,
                                }
                            )
                        if black > 0 and board > 0 and self.cteam[black] == competitor:
                            points = self.get_score(self.gamescore, game, "black")
                            bVur = self.is_vur(game, "black")
                            gpoints += points
                            games.append(
                                {
                                    "points": points,
                                    "rpoints": self.get_score(self.rating, game, "black"),
                                    "color": "b",
                                    "vur": bVur,
                                    "played": game["played"],
                                    "rated": game["rated"] if "rated" in rst else (game["played"] and black > 0),
                                    "player": black,
                                    "opponent": white,
                                    "board": board,
                                }
                            )
                    tmatch["gpoints"] = gpoints
                    if rst[col] is not None and "gpoints" in rst[col]:
                        tmatch["gpoints"] = rst[col]["gpoints"]
                    tmatch["games"] = games
                else:
                    if tmatch["opponent"] == 0 and tmatch["played"]:
                        tmatch["gpoints"] = self.solve_score(self.tournament, score, "match", "PG")
                    else:
                        trans = {"W": "F", "D": "H", "L": "Z"}
                        res = trans[tmatch["res"]] if tmatch["res"] in trans else tmatch["res"]
                        tmatch["gpoints"] = self.solve_score(self.tournament, score, "match", res + "G")
                    tmatch["games"] = []
        self.maxboard = max(self.maxboard, maxboard)

    def addtbval(self, obj, rnd, val):
        rnd = str(rnd)
        if rnd in obj:
            if isinstance(val, str):
                obj[rnd] = obj[rnd] + val
            else:
                obj[rnd] = obj[rnd] + val
        else:
            obj[rnd] = val

    def compute_score(self, cmps, scorename, pointtype, scoretype, norounds):
        prefix = pointtype + "_"
        other = {"w": "b", "b": "w", " ": " "}
        pointsfordraw = scoretype["D"] * (self.teamsize if scorename[0] == "g" else 1)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            tbscore[prefix + "nul"] = {"val": 0}
            tbscore[prefix + "sno"] = {"val": startno}
            tbscore[prefix + "rank"] = {"val": cmp["orgrank"]}
            tbscore[prefix + "rnd"] = {"val": cmp["rnd"]}
            tbscore[prefix + "rtg"] = {"val": cmp["rating"]}
            tbscore[prefix + "cnt"] = {"val": 0}  # count number of elements (why)
            tbscore[prefix + "points"] = {"val": self.zero(scorename)}  # total points
            tbscore[prefix + "win"] = {"val": 0}  # number of wins (played and unplayed)
            tbscore[prefix + "won"] = {"val": 0}  # number of won games over the board
            tbscore[prefix + "bpg"] = {"val": 0}  # number of black games played
            tbscore[prefix + "bwg"] = {"val": 0}  # number of games won with black
            tbscore[prefix + "ge"] = {"val": 0}  # number of games played + PAB
            tbscore[prefix + "rep"] = {"val": 0}  # number of rounds elected to play (same as GE)
            tbscore[prefix + "rip"] = {"val": 0}  # number of rounds paired (for TPN assignment)
            tbscore[prefix + "vur"] = {"val": 0}  # number of vurs (check algorithm)
            # tbscore[prefix + "cop"] = {"val": "nc"}  # color preference (for pairing)
            tbscore[prefix + "cod"] = {"val": 0}  # color difference (for pairing)
            tbscore[prefix + "csq"] = {"val": ""}  # color sequence (for pairing)
            tbscore[prefix + "num"] = {"val": 0}  # number of games played (for pairing)
            tbscore[prefix + "lmp"] = 0  # last round met for pairing
            tbscore[prefix + "lna"] = 0  # last round without absent (vur)
            tbscore[prefix + "pfp"] = Decimal("0")  # points from played games
            tbscore[prefix + "lg"] = Decimal("0")  # Result of last game
            tbscore[prefix + "bp"] = {}  # Boardpoints
            # cmpr = sorted(cmp, key=lambda p: (p['rank'], p['tbval'][prefix + name]['val'], p['cid']))
            pcol = " "  # Previous color
            csq = ""
            for rnd in range(1, norounds + 1):
                if rnd in cmp["rsts"]:
                    rst = cmp["rsts"][rnd]
                    # total score
                    points = rst[pointtype] if pointtype in rst else 0
                    tbscore[prefix + "points"][rnd] = points
                    tbscore[prefix + "points"]["val"] += points
                    # number of games
                    complist = [rst]
                    if self.isteam and scorename == "game":
                        if rst["played"] and rst["opponent"] > 0:
                            gamelist = rst["games"] 
                        else:
                            gamelist =  []
                            points = self.gamescore[rst["res"]]
                            while isinstance(points, str):
                                points = self.gamescore[points]
                            for board in range(self.teamsize):
                                gamelist.append({"points": points, 
                                                  "rpoints": Decimal('0.0'), 
                                                  "color": "w", 
                                                  "vur": rst["vur"], 
                                                  "played": rst["played"], 
                                                  "rated": False,
                                                  "player": 0, 
                                                  "opponent": 0,
                                                  "board": board+1}) 
                    else:
                        gamelist = [rst]
                    for game in gamelist:
                        if self.isteam and scorename == "game":
                            points = game["points"]
                            if game["played"] and game["opponent"] <= 0:  # PAB
                                points = self.gamescore["W"]
                            board = game["board"]
                            tbscore[prefix + "bp"][board] = (
                                tbscore[prefix + "bp"][board] + points if board in tbscore[prefix + "bp"] else points
                            )
                            # tbscore[prefix + 'bp']['val'] += tbscore[prefix + 'bp'][board]

                        self.addtbval(tbscore[prefix + "cnt"], rnd, 1)
                        self.addtbval(tbscore[prefix + "cnt"], "val", 1)

                        # result in last game
                        if rnd == self.rounds and game["opponent"] > 0:
                            tbscore[prefix + "lg"] += points

                        # number of win
                        win = 1 if points == scoretype["W"] else 0
                        self.addtbval(tbscore[prefix + "win"], rnd, win)
                        self.addtbval(tbscore[prefix + "win"], "val", win)

                        # number of win played over the board
                        won = 1 if points == scoretype["W"] and game["played"] and game["opponent"] > 0 else 0
                        self.addtbval(tbscore[prefix + "won"], rnd, won)
                        self.addtbval(tbscore[prefix + "won"], "val", won)

                        # number of games played with black
                        bpg = 1 if game["color"] == "b" and game["played"] else 0
                        self.addtbval(tbscore[prefix + "bpg"], rnd, bpg)
                        self.addtbval(tbscore[prefix + "bpg"], "val", bpg)

                        # number of win played with black
                        bwg = 1 if game["color"] == "b" and game["played"] and points == scoretype["W"] else 0
                        self.addtbval(tbscore[prefix + "bwg"], rnd, bwg)
                        self.addtbval(tbscore[prefix + "bwg"], "val", bwg)

                        ge = 1 if game["played"] or (points == scoretype["W"]) else 0
                        self.addtbval(tbscore[prefix + "ge"], rnd, ge)
                        self.addtbval(tbscore[prefix + "ge"], "val", ge)
                        self.addtbval(tbscore[prefix + "rep"], rnd, ge)
                        self.addtbval(tbscore[prefix + "rep"], "val", ge)

                        # number of gamesin pairing
                        rip = 1 if game["played"] or game["opponent"] > 0 else 0
                        self.addtbval(tbscore[prefix + "rip"], rnd, rip)
                        self.addtbval(tbscore[prefix + "rip"], "val", rip)

                        vur = 1 if game["vur"] else 0
                        self.addtbval(tbscore[prefix + "vur"], rnd, vur)
                        self.addtbval(tbscore[prefix + "vur"], "val", vur)

                        # last round with opponent, pab or fpb (16.2.1, 16.2.2, 16.2.3 and 16.2.4)
                        if rnd > tbscore[prefix + "lna"] and (vur == 0):
                            tbscore[prefix + "lna"] = rnd
                        if rnd > tbscore[prefix + "lmp"] and (game["opponent"] > 0):
                            tbscore[prefix + "lmp"] = rnd

                    for comp in complist:
                        if comp["played"] and comp["opponent"] > 0:
                            ocol = ncol = comp["color"]
                            pf = 1 if ocol == "w" else -1
                            self.addtbval(tbscore[prefix + "cod"], rnd, pf)
                            self.addtbval(tbscore[prefix + "cod"], "val", pf)
                            pf = tbscore[prefix + "cod"]["val"]
                            csq += ocol
                            self.addtbval(tbscore[prefix + "csq"], rnd, ocol)
                            self.addtbval(tbscore[prefix + "csq"], "val", ocol)
    
                            # self.addtbval(tbscore[prefix + "cop"], rnd, ncol)
                            # tbscore[prefix + "cop"]["val"] = ncol
                            #cpa = "N"
                            #if pf < -1   osv
                            #tbscore[prefix + "cop"]["val"] = ncol
                        # points from played games
                        if comp["played"]:
                            self.addtbval(tbscore[prefix + "num"], rnd, comp["opponent"])
                            if comp["opponent"] > 0:
                                self.addtbval(tbscore[prefix + "num"], "val", 1)
                                tbscore[prefix + "pfp"] += points
                            # last played game (or PAB)
                            if rnd > tbscore[prefix + "lmp"]:
                                tbscore[prefix + "lmp"] = rnd
                        elif "points" in comp and comp["points"] == scoretype["W"]:
                            self.addtbval(tbscore[prefix + "num"], rnd, 0)
            adjtype = prefix[:-1]
            adj = sum(adjust[adjtype] for adjust in cmp["adjust"] if adjust["round"] <= norounds and adjust["pairing"])
            top = sum(adjust[adjtype] for adjust in cmp["adjust"] if not adjust["pairing"])
            tbscore[prefix + "points"]["adj"] = adj
            tbscore[prefix + "points"]["top"] = top
            tbscore[prefix + "points"]["val"] += adj




    """
    compute_recursive_if_tied is used for DE, EDE, EDEBT, EDEBB, EDET, EDEB, TBR and BBE
    Foreach loop see if last run untied any more. If not sort all records
    In loopcount 0 initializee all structures
    In loopcount 1 .. n run different parts for example for EDE alternate Primary scoro, secondary score  
    When subrange is empty clean up. We have finished all subranges and will report more_to_do

    """

    def compute_recursive_if_tied(self, tb, cmps, rounds, compute_singlerun):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        name = tb["name"].lower()
        ro = self.rankorder
        for player in ro:
            player["tbval"][prefix + name] = {}
            player["tbval"][prefix + name]["val"] = player["rank"]  # rank value initial value = rank
            player["tbval"]["moreloops"] = True  # As long as True we have more to check
        # part 1, run recursive until no more are tied
        loopcount = 0
        # print("Reciftied",  [s["cid"] for s in cmps.values()], "rounds", rounds)

        moretodo = compute_singlerun(tb, cmps, rounds, ro, loopcount)

        # part 2, Run loop until no more are tied
        while moretodo:
            moretodo = False
            loopcount += 1
            start = 0
            while start < len(ro):
                currentrank = ro[start]["tbval"][prefix + name]["val"]
                for stop in range(start + 1, len(ro) + 1):
                    if stop == len(ro) or currentrank != ro[stop]["tbval"][prefix + name]["val"]:
                        break
                # we have a range start .. stop-1 to check for top board result
                if ro[start]["tbval"]["moreloops"]:
                    if stop - start == 1:
                        moreloops = False
                        ro[start]["tbval"]["moreloops"] = moreloops
                    else:
                        subro = ro[start:stop]  # subarray of rankorder
                        moreloops = compute_singlerun(tb, cmps, rounds, subro, loopcount)
                        for player in subro:
                            player["tbval"]["moreloops"] = moreloops  # 'de' rank value initial value = rank
                        moretodo = moretodo or moreloops
                start = stop
            # json.dump(ro, sys.stdout, indent=2)
            moreloops = compute_singlerun(tb, cmps, rounds, [], loopcount)
            moretodo = moretodo or moreloops
            ro = sorted(ro, key=lambda p: (p["rank"], p["tbval"][prefix + name]["val"], p["cid"]))
            # print([(s['rank'], s["tbval"][prefix + name]["val"], s["cid"]) for s in ro])

        # part 2, Reorder rank
        start = 0
        while start < len(ro):
            currentrank = ro[start]["rank"]
            for stop in range(start, len(ro) + 1):
                if stop == len(ro) or currentrank != ro[stop]["rank"]:
                    break
                # we have a range start .. stop-1 to check for direct encounter
            offset = ro[start]["tbval"][prefix + name]["val"]
            if ro[start]["tbval"][prefix + name]["val"] != ro[stop - 1]["tbval"][prefix + name]["val"]:
                offset -= 1
            for p in range(start, stop):
                ro[p]["tbval"][prefix + name]["val"] -= offset
            start = stop
        return name

    # -----------------
    # Direct encounter
    #

    
    def compute_direct_encounter(self, tb, cmps, rounds):
        func = self.compute_singlerun_ext_direct_encounter
        return self.compute_recursive_if_tied(tb, cmps, rounds, func)
 
    def compute_ext_direct_encounter(self, tb, cmps, rounds):
        if tb["name"] in ["EDEC", "EDEBT", "EDEBB"]:
            self.compute_boardcount(tb, cmps, self.currentround)
        func = self.compute_singlerun_ext_direct_encounter
        return self.compute_recursive_if_tied(tb, cmps, rounds, func)

    # -----------------
    # Compute compute_singlerun_ext_direct_encounter
    #
    # The core in DE, EDE and also  EDEBT, EDEBB, EDET, EDEB, 
    # We compute the average score against all opponents on the same rank. 
    # If not all opponents have met we compute the maximum possible score against all opponents on the same rank.
    # Parameters:
    #   tb - tiebreak structure
    #   cmps - competitors structure
    #   subro - subrange of competitors on the same rank
    #   loopcount - number of recursive run, 0 = first run, 1 = second run, etc
    #   points - which score to use, mpoints, gpoints or points
    #   scorename - which score to use, match, game or points
    #   scoretype - Translate result W, D, L, Z, F .. to score value, for example W=1.0, D=0.5, L=0.0, Z=0.0
    #   prefix - prefix for score, mpoints_, gpoints_ or points_ 
    # Output:
    #   changes - number of changes in rank, if 0 we have finished
    #
    # EDE - Primary Score - Secondary score
    # EDEC - Primary Score - Secondary score - BC
    # EDET - Primary Score - Secondary score - TBR
    # EDEB - Primary Score - Secondary score - BBE
    # EDEBT - Primary Score - Secondary score - BC -TBR
    # EDEBB - Primary Score - Secondary score - BC - BBE
    # Does work ...


    def compute_singlerun_ext_direct_encounter(self, tb, cmps, rounds, subro, loopcount):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        # name = tb["name"].lower()
        # The loops is controlled by:
        # tb["ede"]["loopcount"] = The current loopcount, for example 0 = initial run, 1 = first run, etc
        # tb["ede"]["functions"] - The functions to run in order, for example "PSCT" (primary, secondary, count, topboard)
        # tb["ede"]["edechanges"] - A list of booleans for each function, True = we have changes, False = no changes
        # tb["ede"]["swap"] - The current function to run, for example 0 = primary, 1 = secondary, 2 = count, 3 = topboard
        # tb["ede"]["num"] - Number of times a function has been run, used for BC, TBR and BBE.
        # tb["ede"]["changes"] - The number of changes in the current function,

        # print("Singlerun_Ext", loopcount, [s["cid"] for s in subro])
        changes = 0  # Changes for this subrange
        # Initialize functions to run in loopcount 0, for example EDEBT = "PSCT" (primary, secondary, count, topboard)
        if loopcount == 0:
            functype = {
                "DE": "P", 
                "EDE": "PS", 
                "EDEC": "PSC", 
                "EDET": "PS" + "T" * self.teamsize, 
                "EDEB": "PS" + "B" * (self.teamsize-1), 
                "EDEBT": "PSC" + "T" * self.teamsize, 
                "EDEBB": "PSC" + "B" * (self.teamsize-1),
            }
            tb["ede"] = {}
            tb["ede"]["functions"] = functions = functype[tb["name"]]
            tb["ede"]["loopcount"] = 0
            tb["ede"]["edechanges"] = [True] * len(functions)
            tb["ede"]["swap"] = 0
            return True

        # A new loopcount means we have finished a run, so reset changes to 0
        if tb["ede"]["loopcount"] != loopcount:
            tb["ede"]["loopcount"] = loopcount
            tb["ede"]["changes"] = 0

        # Last competitors finished. We have finished all subranges and will report more_to_do
        if len(subro) == 0:
            # print(tb["ede"])
            changes = tb["ede"]["changes"] 
            swap = tb["ede"]["swap"]
            tb["ede"]["edechanges"][swap] = changes > 0
            moretodo = any(tb["ede"]["edechanges"])
            if changes == 0:
                tb["ede"]["swap"] = (swap + 1) % len(tb["ede"]["functions"])
                ro = self.rankorder
                for player in ro:
                    player["tbval"]["moreloops"] = True  # 'de' rank value initial value = rank
            else:
                tb["ede"]["edechanges"] = [True for _ in tb["ede"]["edechanges"]] 
                # print("CNT", loopcount, changes, tb["ede"]["edechanges"], tb["ede"]["swap"], moretodo)      
            # print("FIN", loopcount, changes, tb["ede"]["edechanges"], tb["ede"]["swap"], moretodo  )         
            return moretodo and loopcount < 30
 
        # For all subranges we run the function for the current swap (primary, secondary, count, topboard)
        swap = tb["ede"]["swap"]
        func = tb["ede"]["functions"][swap]
        #breakpoint()
        if func == "P" or func == "S":
            (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, func == "P")
            changes += self.compute_basic_direct_encounter(tb, func, cmps, rounds, subro, loopcount, points, scorename, scoretype, prefix)
        elif func == "C" or func == "T" or func == "B":
            if len(subro) == 2:  # 13.3.2,  If exactly two teams are still tied in both MP and GP
                (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, False)
                substr = tb["ede"]["functions"][0:swap]
                pos = swap - (len(substr) - substr.count(func))
                if func == "C":
                    # Board Count is the exceptional lower-is-better board criterion.
                    # The direct-encounter helper ranks larger scores first, so compare
                    # the negated weighted total here.
                    weights = [-i for i in range(1, self.teamsize + 1)]
                elif func == "T":
                    weights = [1 if i == pos else 0 for i in range(self.teamsize )]
                elif func == "B":
                    weights = [1 if i >  pos else 0 for i in range(self.teamsize-1, -1, -1)]
                for cmp in subro:
                    rsts = cmp["rsts"]
                    for rst in rsts.values():
                        games = rst["games"] if "games" in rst else []
                        tscore = Decimal("0.0")
                        for game in games:
                            tscore += weights[game["board"]-1] * game["points"]
                        rst["tpoints"] = tscore
                # breakpoint()
                changes += self.compute_basic_direct_encounter(
                    tb, func, cmps, rounds, subro, loopcount, "tpoints", scorename, scoretype, prefix
                )

        
        tb["ede"]["changes"] += changes
        # print("EDE", loopcount, func, changes, tb["ede"]["edechanges"], tb["ede"]["swap"], tb["ede"]["changes"]  )
        return changes and loopcount < 30


    # -----------------
    # Compute Basic Direct encounter
    #

    def compute_basic_direct_encounter(self, tb, func, cmps, rounds, subro, loopcount, points, scorename, scoretype, prefix):
        name = tb["name"].lower()
        (_, _, _, prefix) = self.get_scoreinfo(tb, True)
        # changes keep track of number of changes in rank, if 0 we have finished
        changes = 0
        sign = -1  # Board Count is already negated; all other scores prefer larger values.
        # print("Basic", func, sign, loopcount, [s["cid"] for s in subro])
        rpos = loopcount - tb["ede"]["swap"]  # Report pos
        postfix = "_" + scorename[0] if tb["name"][0:3] == "EDE" else "" # _g or _m for EDE, EDEBT, EDEBB, EDET, EDEB
        currentrank = subro[0]["tbval"][prefix + name]["val"]  # All players in subro have same rank
        metall = True  # Met all opponents on same range
        metmax = len(subro) - 1  # Max number of opponents
        # print("Compute Basic Direct encounter", postfix, loopcount, [s["cid"] for s in subro], currentrank, metmax)
        # For all plyers in subro compute average score against all opponents on the same rank. 
        # If not all opponents have met we compute the maximum possible score against all opponents on the same rank.
        for player in range(0, len(subro)):
            de = subro[player]["tbval"]
            de["denum"] = 0  # number of unique opponens
            de["deval"] = Decimal("0")  # sum score against of opponens
            de["demax"] = Decimal("0")  # sum score against of opponens, unplayed = win
            de["delist"] = {}  # list of results numgames, score, maxscore
            for rnd, rst in subro[player]["rsts"].items():
                if rnd <= rounds:
                    opponent = rst["opponent"]
                    if opponent > 0:
                        played = True if tb["modifiers"].get("predetermined", False) else rst["played"]
                        if played and cmps[opponent]["tbval"][prefix + name]["val"] == currentrank:
                            # 6.1.2 compute average score
                            if opponent in de["delist"]:
                                score = de["delist"][opponent]["score"]
                                num = de["delist"][opponent]["cnt"]
                                sumscore = score * num
                                de["deval"] -= score
                                num += 1
                                sumscore += rst[points]
                                score = sumscore / num
                                #de["denum"] = 1
                                de["deval"] += score
                                de["delist"][opponent]["cnt"] += 1
                                de["delist"][opponent]["score"] = score
                            else:
                                de["denum"] += 1
                                de["deval"] += rst[points]
                                de["delist"][opponent] = {"cnt": 1, "score": rst[points]}
            # if not tb['modifiers']['predetermined'] and de['denum'] < metmax:
            # if (not tb['modifiers']['predetermined'] and de['denum'] < metmax) or tb['modifiers']['swiss']:
             
            if (not self.rr and de["denum"] < metmax) or tb["modifiers"].get("swiss", False):
                metall = False
                de["demax"] = de["deval"] + (metmax - de["denum"]) * scoretype["W"] * (self.teamsize if points == "gpoints" else 1)
            else:
                de["demax"] = de["deval"]
            # print("Player", metall, metmax, subro[player]["cid"], "denum", de["denum"], "deval", de["deval"], "demax", de["demax"])
        
        # 6.2 If all players have met we compute the average score against all opponents on the same rank.
        if metall:  # 6.2 All players have met
            # print("T")
            subro = sorted(subro, key=lambda p: (sign * p["tbval"]["deval"], p["cid"]))
            crank = rank = subro[0]["tbval"][prefix + name]["val"] 
            # This is still currentrank, but we will change it if we find a different score
            val = subro[0]["tbval"]["deval"]
            sprefix = "\t" if rpos in subro[0]["tbval"][prefix + name] else ""
            self.addtbval(subro[0]["tbval"][prefix + name], rpos, sprefix + str(val) + postfix)
            for i in range(1, len(subro)):
                rank += 1
                de = subro[i]["tbval"]
                if val != de["deval"]:
                    crank = de[prefix + name]["val"] = rank
                    val = de["deval"]
                    changes += 1
                else:
                    de[prefix + name]["val"] = crank
                sprefix = "\t" if rpos in de[prefix + name] else ""
                self.addtbval(de[prefix + name], rpos, sprefix + str(val) + postfix)
        else:  # 6.2 swiss tournament. Not all players have met. We compute the maximum possible score against all opponents on the same rank.
            # print("F")
            subro = sorted(subro, key=lambda p: (sign * p["tbval"]["deval"], -p["tbval"]["demax"], p["cid"]))
            crank = rank = subro[0]["tbval"][prefix + name]["val"]
            # This is still currentrank, but we will change it if we find a different score
            val = subro[0]["tbval"]["deval"]
            maxval = subro[0]["tbval"]["demax"]
            sprefix = "\t" if rpos in subro[0]["tbval"][prefix + name] else ""
            self.addtbval(subro[0]["tbval"][prefix + name], rpos, sprefix + str(val) + "/" + str(maxval) + postfix)
            unique = True
            # continue as long as we have unique maximum score, 
            # if not we will assign the same rank to all players with the same maximum score
            for i in range(1, len(subro)):
                rank += 1
                tbmax = max(subro[i:], key=lambda tbval: tbval["tbval"]["demax"])
                de = subro[i]["tbval"]
                if unique and val > tbmax["tbval"]["demax"]:
                    crank = de[prefix + name]["val"] = rank
                    val = de["deval"]
                    maxval = de["demax"]
                    changes += 1
                else:
                    val = de["deval"]
                    maxval = de["demax"]
                    de[prefix + name]["val"] = crank
                    unique = False
                sprefix = "\t" if rpos in de[prefix + name] else ""
                self.addtbval(de[prefix + name], rpos, sprefix + str(val) + "/" + str(maxval) + postfix)
                # self.addtbval(de[prefix + name], rpos,  str(val) + '/' + str(maxval) + postfix)
            # print(unique)
        return changes



    def compute_progressive_score(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        low = tb["modifiers"].get("cutlow", 0)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            ps = 0
            ssf = 0  # Sum so far
            tbscore[prefix + "ps"] = {"val": ps, "cut": []}
            for rnd in range(1, rounds + 1):
                p = cmp["rsts"][rnd][points] if rnd in cmp["rsts"] and points in cmp["rsts"][rnd] else self.zero(scorename)
                ssf += p
                # p = p * (rounds+1-rnd)
                tbscore[prefix + "ps"][rnd] = ssf
                if rnd <= low:
                    tbscore[prefix + "ps"]["cut"].append(rnd)
                else:
                    ps += ssf
            tbscore[prefix + "ps"]["val"] = ps
        return "ps"

    def compute_koya(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        plim = tb["modifiers"].get("plim", Decimal("50.0"))
        nlim = tb["modifiers"].get("nlim", Decimal("0.0"))
        competitors = len(cmps)
        maxgames = rounds
        # if RoundRobin with odd number of players the number of games is reduced by 1 (2, for double rr, ...)
        if self.rr:
            if rounds % competitors == 0:
                maxgames -= rounds//competitors
            for startno, cmp in cmps.items():
                tbscore = cmp["tbval"]
                if tbscore[prefix + "lmp"] == 0: # Never paierd
                    maxgames -= 1
        lim = plim * scoretype["W"] * maxgames * (self.teamsize if points == "gpoints" else 1) / Decimal("100.0") + nlim
        # print(maxgames, lim)
                    
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            ks = 0
            tbscore[prefix + "ks"] = {"val": ks, "cut": []}
            for rnd, rst in cmp["rsts"].items():
                if rnd <= rounds:
                    opponent = rst["opponent"]
                    if opponent > 0:
                        oppscore = cmps[opponent]["tbval"][prefix + "points"]["val"]
                        ownscore = cmp["tbval"][prefix + "points"][rnd]
                        tbscore[prefix + "ks"][rnd] = ownscore
                        if oppscore >= lim:
                            ks += ownscore
                        else:
                            tbscore[prefix + "ks"]["cut"].append(rnd)
            tbscore[prefix + "ks"]["val"] = ks
        return "ks"

    def compute_buchholz_sonneborn_berger(self, tb, cmps, rounds):
        version = self.rulesversion
        if tb["modifiers"]["ver"]:
            version = max(self.TIEBREAK_RULES.keys())
        tbname = self.compute_buchholz_sonneborn_berger_ver(tb, cmps, rounds, version)
        return tbname
        
    def compute_ext_sonneborn_berger(self, tb, cmps, rounds):
        if len(tb["name"]) == 5:
            tb["pointtype"] = tb["name"][1:3].lower() + "points"
        tbname = self.compute_buchholz_sonneborn_berger(tb, cmps, self.currentround)
        return tbname


    def compute_buchholz_sonneborn_berger_ver(self, tb, cmps, rounds, version):
        name = tb["name"].lower()
        isfb = name == "fb" or name == "afb" or tb["modifiers"].get("foremode", False)
        # For adjustment and fore two variables are important:
        # tbscore[vprefix + "lmp"] = Last round met for pairing (played or unplayed)
        # tbscore[vprefix + "lna"] = Last round met not abent (not VUR)   
        (oscorename, opoints, oscoretype, oprefix) = self.get_scoreinfo(tb, True)
        (sscorename, spoints, sscoretype, sprefix) = self.get_scoreinfo(tb, name == "sb")
        vprefix = "mpoints_" if self.isteam else "points_" # prefix for unplayed games
        opointsfordraw = oscoretype["D"] * (self.teamsize if opoints == "gpoints" else 1)
        spointsfordraw = sscoretype["D"] * (self.teamsize if spoints == "gpoints" else 1)
        # print("Pointsfordraw",  oprefix, opointsfordraw, sprefix, spointsfordraw)
        name = tb["name"].lower()
        if name == "aob":
            name = "bh"
        is_sb = name == "sb" or name == "esb" or (len(name) == 5 and name[0] == "e" and name[3:5] == "sb")
        if name == "esb" or (len(name) == 5 and name[0] == "e" and name[3:5] == "sb"):
            (sscorename, spoints, sscoretype, sprefix) = self.get_scoreinfo(tb, False)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            tbscore[oprefix + "abh"] = {"val": 0}  # Adjusted score for BH (check algorithm)
            # 16.3.2    Unplayed rounds of category 16.2.5 are evaluated as draws.
            if isfb and tbscore[vprefix + "lmp"] == self.rounds:
                tbscore[vprefix + "lna"] = tbscore[vprefix + "lmp"] 
            isfore = isfb and tbscore[vprefix + "lmp"] == self.rounds  # do we need to adjust for Fore
            adjustfore = False
            for rnd, rst in cmp["rsts"].items():
                if rnd <= rounds:
                    points_no_opp = self.zero(oscorename) if self.rr else opointsfordraw
                    hasopponent = rnd <= tbscore[oprefix + "lna"] or rst["opponent"] > 0
                    adjustfore = adjustfore or (isfore and rnd == rounds and rst["opponent"] > 0)
                    tbval = rst[opoints] if hasopponent else points_no_opp
                    tbscore[oprefix + "abh"][rnd] = tbval
                    tbscore[oprefix + "abh"]["val"] += tbval
            # tbscore[oprefix + "abh"]["val"] += tbscore[oprefix + "points"]["adj"]
            fbscore = tbscore[oprefix + "points"]["val"]
            if adjustfore:
                adjust = opointsfordraw - tbscore[oprefix + "points"][rnd]
                tbscore[oprefix + "abh"][self.rounds] += adjust
                tbscore[oprefix + "abh"]["val"] += adjust
                fbscore += adjust
            tbscore[oprefix + "ownscore"] = fbscore
            #if version == 2:
            #    tbscore[oprefix + "abh"] = max(tbscore[oprefix + "abh"], opointsfordraw * rounds)
                
        if name == "abh" or name == "afb":
            return "abh"

        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            bhvalue = []
            for rnd, rst in cmp["rsts"].items():
                if rnd <= rounds:
                    opponent = rst["opponent"]
                    vur = rst["vur"]
                    played = True if tb["modifiers"].get("predetermined", False) or (isfb and rnd == self.rounds) else rst["played"]
                    if played and opponent > 0:
                        vur = False
                        score = cmps[opponent]["tbval"][oprefix + "abh"]["val"]
                    elif not self.rr:
                        score = cmps[startno]["tbval"][oprefix + "ownscore"]
                        if tb["modifiers"]["ver"] == 2: # 2026-02-01
                            if opponent > 0:  # 16.4.1
                                score = min(score, cmps[opponent]["tbval"][oprefix + "abh"]["val"])
                            else:             # 16.4.2
                                # "number of rounds in the tournament": 
                                # for intermediate rounds, the number of rounds played so far, for the last round, the total number of rounds in the tournament
                                score = min(score, opointsfordraw * rounds)
                    else:
                        score = Decimal("0")
                    if tb["modifiers"].get("urd", False) and not self.rr:
                        sres = spointsfordraw
                    else:
                        sres = rst[spoints] if spoints in rst else self.zero(sscorename)
                    tbvalue = score * sres if is_sb else score
                    # if  opponent >  0 or not tb['modifiers']['predetermined'] :
                    if opponent > 0 or not self.rr:
                        bhvalue.append({"vur": vur, "tbvalue": tbvalue, "score": score, "rnd": rnd})
            tbscore = cmp["tbval"]
            tbscore[oprefix + name] = {"val": 0, "cut": []}
            for game in bhvalue:
                self.addtbval(tbscore[oprefix + name], game["rnd"], game["tbvalue"])

            low = tb["modifiers"].get("cutlow", 0)
            if low > rounds:
                low = rounds
            high = tb["modifiers"].get("cuthigh", 0)
            if low + high > rounds:
                high = rounds - low
            vun = tb["modifiers"].get("vun", False) # unpublished proposal by Roberto
            while low > 0 and len(bhvalue) > 0:
                sortall = sorted(bhvalue, key=lambda game: (game["score"], game["tbvalue"]))
                sortexp = sorted(bhvalue, key=lambda game: (-game["vur"], game["tbvalue"], game["score"]))
                if (not sortexp[0]["vur"]) or (sortall[0]["tbvalue"] > sortexp[0]["tbvalue"]) or vun:
                    bhvalue = sortall[1:]
                    tbscore[oprefix + name]["cut"].append(sortall[0]["rnd"])
                else:
                    bhvalue = sortexp[1:]
                    tbscore[oprefix + name]["cut"].append(sortexp[0]["rnd"])
                low -= 1
            while high > 0 and len(bhvalue) > 0:
                sortall = sorted(bhvalue, key=lambda game: (-game["score"], -game["tbvalue"]))
                # sortexp = sorted(bhvalue, key=lambda game: (-game['vur'], -game['score'], -game['tbvalue'])) // No
                # exception on high
                sortexp = sorted(bhvalue, key=lambda game: (-game["score"], -game["tbvalue"]))
                if vun:
                    bhvalue = sortall[1:]
                    tbscore[oprefix + name]["cut"].append(sortall[0]["rnd"])
                else:
                    bhvalue = sortexp[1:]
                    tbscore[oprefix + name]["cut"].append(sortexp[0]["rnd"])
                high -= 1

            #            if high > 0:
            #                if tb['modifiers']['vun']:
            #                    bhvalue = sorted(bhvalue, key=lambda game: (-game['score'], -game['tbvalue']))[high:]
            #                else:
            #                    bhvalue = sorted(bhvalue, key=lambda game: (game['played'], -game['score'],
            #                    -game['tbvalue']))[high:]

            for game in bhvalue:
                self.addtbval(tbscore[oprefix + name], "val", game["tbvalue"])
        return name


    def compute_rtng(self, tb, cmps, rounds):
        self.compute_acc(tb, cmps, rounds)
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        last = self.rounds - 1
        unrated = tb["modifiers"].get("unrated", self.unrated)
        competitors = list(cmps.values())
        allrated = unrated is not None or all([cmp["tbval"][prefix + "rtg"]["val"] is not None for cmp in competitors])
        for cmp in competitors:
            tbscore = cmp["tbval"]
            rtng = tbscore[prefix + "rtg"]["val"] if tbscore[prefix + "rtg"]["val"] is not None else unrated
            tbscore[prefix + "rtng"] = {"val": rtng if allrated else None}
        self.allrated = allrated
        return "rtng"


    def compute_ratingperformance(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        name = tb["name"].lower()
        self.compute_rtng(tb, cmps, rounds)
        valid = self.allrated
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            tbscore[prefix + "aro"] = {"val": 0, "cut": []}
            tbscore[prefix + "tpr"] = {"val": 0, "cut": []}
            tbscore[prefix + "ptp"] = {"val": 0, "cut": []}
            tbscore[prefix + "rses"] = {"val": 0, "cut": []}
            ratingopp = []
            unrated = tb["modifiers"].get("unrated", self.unrated)
            # trounds
            trounds = 0
            for rnd, rst in cmp["rsts"].items():
                if rnd <= rounds and rst["played"] and rst["opponent"] > 0:
                    trounds += 1
                    if rst["opprating"] is not None or unrated is not None:
                        rst["rnd"] = rnd
                        rst["adjrating"] = rtng = rst["opprating"] if rst["opprating"] is not None else unrated
                        ratingopp.append(rst)
                        self.addtbval(cmp["tbval"][prefix + "aro"], rnd, rtng)
                        self.addtbval(cmp["tbval"][prefix + "tpr"], rnd, rtng)
                        self.addtbval(cmp["tbval"][prefix + "ptp"], rnd, rtng)
            # trounds = rounds  // This is correct only if unplayed gmes are cut.
            ver = tb["modifiers"]["ver"]
            low = tb["modifiers"].get("cutlow", 0)
            if low > rounds:
                low = rounds
            high = tb["modifiers"].get("cuthigh", 0)
            if low + high > rounds:
                high = rounds - low
            if ver == 0 and (low > 0 or high > 0) : # Rules 2022 for WCC Blitz and Rapid
                unplayed = rounds - trounds
                diff = min(unplayed, low)
                low -= diff
                diff = min(unplayed - diff, high)
                high -= diff
            while low > 0:
                if trounds == len(ratingopp):
                    newopp = sorted(ratingopp, key=lambda p: (p["adjrating"]))
                    if len(newopp) > 0:
                        tbscore[prefix + name]["cut"].append(newopp[0]["rnd"])
                    ratingopp = newopp[1:]
                trounds -= 1
                low -= 1
            while high > 0:
                if trounds == len(ratingopp):
                    newopp = sorted(ratingopp, key=lambda p: (p["adjrating"]))
                    if len(newopp) > 0:
                        tbscore[prefix + name]["cut"].append(newopp[-1]["rnd"])
                    ratingopp = newopp[:-1]
                trounds -= 1
                high -= 1
            rscore = Decimal("0")
            ratings = []
            for p in ratingopp:
                rscore += p["rpoints"]
                ratings.append(p["adjrating"])
            tbscore[prefix + "aro"]["val"] = rating.ComputeAverageRatingOpponents(ratings) if valid else None
            tbscore[prefix + "tpr"]["val"] = rating.ComputeTournamentPerformanceRating(rscore, ratings) if valid else None
            tbscore[prefix + "ptp"]["val"] = rating.ComputePerfectTournamentPerformance(rscore, ratings) if valid else None
            tbscore[prefix + "rses"]["val"] = rating.ComputeSumExpectedScore(tbscore[prefix + "rtg"]["val"], ratings) if valid else None
        return tb["name"].lower()

    def compute_boardcount(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            bc = 0
            tbscore[prefix + "bc"] = {"val": bc}
            for val, points in tbscore["gpoints_" + "bp"].items():
                bc += val * points
                self.addtbval(tbscore[prefix + "bc"], val, val * points)
            tbscore[prefix + "bc"]["val"] = bc
        return "bc"

    def compute_top_bottom_board(self, tb, cmps, rounds):
        tbname = self.compute_recursive_if_tied(tb, cmps, rounds, self.compute_singlerun_topbottomboardresult)
        return tbname

    def compute_singlerun_topbottomboardresult(self, tb, cmps, rounds, ro, loopcount):
        name = tb["name"].lower()
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        if loopcount == 0:
            for player in ro:
                player["tbval"]["tbrval"] = self.zero(scorename)
                player["tbval"]["bbeval"] = self.zero(scorename)
                for val, points in player["tbval"]["gpoints_" + "bp"].items():
                    player["tbval"]["bbeval"] += points
            return True
        if len(ro) == 0:
            return False
        for player in range(0, len(ro)):
            ro[player]["tbval"]["tbrval"] = ro[player]["tbval"]["gpoints_" + "bp"][loopcount]
            ro[player]["tbval"]["bbeval"] -= ro[player]["tbval"]["gpoints_" + "bp"][self.maxboard - loopcount + 1]
        subro = sorted(ro, key=lambda p: (-p["tbval"][name + "val"], p["cid"]))
        count = currentrank = ro[0]["tbval"][prefix + name]["val"]
        for player in range(0, len(subro)):
            if subro[player]["tbval"][name + "val"] != subro[player - 1]["tbval"][name + "val"]:
                currentrank = count
            subro[player]["tbval"][prefix + name]["val"] = currentrank
            self.addtbval(subro[player]["tbval"][prefix + name], loopcount, subro[player]["tbval"][name + "val"])
            count += 1
        return loopcount < self.maxboard

    def compute_score_strength_combination(self, tb, cmps, currentround):
        self.compute_buchholz_sonneborn_berger(tb, cmps, currentround)
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        for startno, cmp in cmps.items():
            dividend = cmp["tbval"][prefix + "sssc"]["val"]
            divisor = 1
            key = points[0]
            if key == "m":
                score = cmp["tbval"]["gpoints_" + "points"]["val"]
                divisor = math.floor(scoretype["W"] * currentround / self.gamescore["W"] / self.maxboard)
            elif key == "g":
                score = cmp["tbval"]["mpoints_" + "points"]["val"]
                divisor = math.floor(scoretype["W"] * currentround * self.maxboard / self.matchscore["W"])
            nlim = tb["modifiers"].get("nlim", Decimal("0.0"))
            if nlim > 0:
                divisor = nlim
            val = (score + dividend / divisor).quantize(Decimal(".01"), rounding=ROUND_HALF_UP)
            cmp["tbval"][prefix + "sssc"] = {"val": val}
        return "sssc"

    def get_accelerated(self, prefix, rnd, startno):
        acc = Decimal("0.0")
        if self.accelerated is None:
            return acc
        for val in self.accelerated["values"]:
            if (
                rnd >= val["firstRound"]
                and rnd <= val["lastRound"]
                and startno >= val["firstCompetitor"]
                and startno <= val["lastCompetitor"]
            ):
                # game points for an individual score and for a team's game-point
                # score, which ACC/X reaches as gpoints_ when match points are primary
                acc = val["gamePoints"] if prefix in ("points_", "gpoints_") else val["matchPoints"]
        return acc

    # STD: 1.0/ 0.5 /0.0 point system

    def compute_std(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        pointsfordraw = scoretype["D"]
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            tbscore[prefix + "std"] = {"val": Decimal("0.0"), 0: Decimal("0.0")}
            for rnd in range(1, rounds + 1):
                #breakpoint()                
                if scorename == "match" or self.teamsize <= 1:
                    p = cmp["rsts"][rnd][points] if rnd in cmp["rsts"] and points in cmp["rsts"][rnd] else Decimal("0.0")
                    # std from 2026 rules, does not work for 
                    if p > pointsfordraw:
                        std = Decimal("1.0")
                    elif p == pointsfordraw:
                        std = Decimal("0.5")
                    else:
                        std = Decimal("0.0")
                elif cmp["rsts"][rnd]["played"] and cmp["rsts"][rnd]["opponent"] > 0:
                    std = Decimal("0.0")
                    for game in cmp["rsts"][rnd]['games']:
                        p = game["points"]
                        if p > pointsfordraw:
                            std += Decimal("1.0")
                        elif p == pointsfordraw:
                            std += Decimal("0.5")
                else:
                    pointsfordraw = self.gamescore["D"]                  
                    p = self.gamescore[cmp["rsts"][rnd]["res"]]
                    while isinstance(p, str):
                        p = self.gamescore[p]
                    if p > pointsfordraw:
                        std = Decimal("1.0")
                    elif p == pointsfordraw:
                        std = Decimal("0.5")
                    else:
                        std = Decimal("0.0")
                    std = std * self.teamsize
                tbscore[prefix + "std"][rnd] = std
                tbscore[prefix + "std"]["val"] += std
                #print(pointsfordraw, p, std, tbscore[prefix + "std"]["val"])
                #breakpoint()
        return "std"

    def compute_pts(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        if prefix + "pts" in cmps[1]["tbval"]:
            return "pts"

        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            tbscore[prefix + "pts"] = tbscore[prefix + "points"].copy()
            tbscore[prefix + "pts"]["val"] += tbscore[prefix + "pts"]["top"]
        return "pts"


    def compute_acc(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        if prefix + "acc" in cmps[1]["tbval"]:
            return "acc"

        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            acc = self.get_accelerated(prefix, 1, startno)
            val = acc # scoretype[acc]
            tbscore[prefix + "acc"] = {"val": acc, 0: acc}
            spoints = Decimal("0")  # Points so far
            for rnd in range(1, rounds + 1):
                p = cmp["rsts"][rnd][points] if rnd in cmp["rsts"] and points in cmp["rsts"][rnd] else self.zero(scorename)
                spoints += p
                acc = self.get_accelerated(prefix, rnd + 1, startno)  # Round 0 shall have the value of 1 and so on
                val = spoints + acc
                tbscore[prefix + "acc"][rnd] = val
            tbscore[prefix + "acc"]["val"] = val + tbscore[prefix + "points"]["adj"]
        return "acc"

    def compute_flt(self, tb, cmps, rounds, rules):
        self.compute_acc(tb, cmps, rounds)
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            tbscore[prefix + "flt"] = {"val": 0}
            nfloat = 0  # Float so far as numeric
            sfloat = ""  # Float so far as string
            for rnd in range(1, rounds + 1):
                nfloat *= 4
                pts = cmp["rsts"][rnd][points] if rnd in cmp["rsts"] and points in cmp["rsts"][rnd] else self.zero(scorename)
                opp = cmp["rsts"][rnd]["opponent"] if rnd in cmp["rsts"] and "opponent" in cmp["rsts"][rnd] else 0
                # ownacc = own points + accellerated
                # oppacc = opponent points + accellerated
                if opp > 0 and cmp["rsts"][rnd]["played"]:
                    ownacc = cmp["tbval"][prefix + "acc"][rnd - 1]
                    oppacc = cmps[opp]["tbval"][prefix + "acc"][rnd - 1]
                elif rules == "dutch" and (pts > scoretype["L"] or cmp["rsts"][rnd]["played"]):  # Have points without playing, more than points for loss
                    ownacc = 1
                    oppacc = 0
                else:
                    ownacc = 0
                    oppacc = 0
                if ownacc > oppacc:
                    cfloat = "d"
                    ifloat = 1
                elif ownacc < oppacc:
                    cfloat = "u"
                    ifloat = 2
                else:
                    cfloat = "-"
                    ifloat = 0
                if rnd == 1 and cfloat == "u":
                    pass
                self.addtbval(tbscore[prefix + "flt"], rnd, cfloat)
                nfloat += ifloat
                sfloat += cfloat
            fac = {"dutch": 16, "fideteam": 4}[rules]
            tbscore[prefix + "flt"]["val"] = (sfloat if tb["modifiers"].get("swiss", False) else nfloat) % fac
        return "flt"

    def compute_flt_dutch(self, tb, cmps, rounds):
        return self.compute_flt(tb, cmps, rounds, "dutch")

    def compute_flt_team(self, tb, cmps, rounds):
        return self.compute_flt(tb, cmps, rounds, "fideteam")


    def compute_rfp(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            val = True
            tbscore[prefix + "rfp"] = {"val": val}
            for rnd in range(1, rounds + 2):
                val = True
                if rnd in cmp["rsts"]:
                    if cmp["rsts"][rnd]["opponent"] == 0:
                        clr = "w"
                    elif startno == 0:
                        clr = "b"
                    else:
                        clr = cmp["rsts"][rnd]["color"]
                    val = (
                        str(cmp["rsts"][rnd]["opponent"]) + clr
                        if cmp["rsts"][rnd]["played"] or (cmp["rsts"][rnd]["opponent"] > 0)
                        else "N"
                    )
                elif rnd > self.lastplayedround:
                    val = "Y" if cmp["present"] else "N"
                else:
                    val = "N"
                if rnd <= rounds:
                    val = "pab" if val == "0w" else val
                    if not cmp["rsts"][rnd]["played"]:
                        res = cmp["rsts"][rnd]["res"]
                        # .get(res, res), not a bare subscript: res is a scoreSystem result
                        # letter (W, D, L, F, H, Z, P, A, U -- see scoresystem.py's
                        # default_score, and record 299 can write F/H directly onto a game,
                        # per TRF-2026's Abnormal Assignment section), and these two tables
                        # only ever enumerated a subset of it. A letter neither table names
                        # is already in its final display form, exactly the fallback
                        # compute_score takes a few lines above for the same "translate a
                        # result letter, or leave it alone" job (the `trans` dict there).
                        # Un-enumerated letters used to raise KeyError out of the middle of
                        # a tie-break computation on an ordinary, valid TRF file -- e.g. any
                        # tournament recording a half-point bye ("H") directly on a game.
                        if cmp["rsts"][rnd]["opponent"]:
                            val = {"W": "+", "D": "=", "L": "-", "P": "pab", "A": "=", "U": "-", "Z": "-"}.get(res, res)
                        else:
                            val = {"W": "F", "D": "H", "L": "Z", "P": "pab", "A": "=", "U": "-", "Z": "Z"}.get(res, res)
                    tbscore[prefix + "rfp"][rnd] = val
            tbscore[prefix + "rfp"]["val"] = val
        return "rfp"

    def compute_top(self, tb, cmps, rounds):
        self.compute_acc(tb, cmps, rounds)
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        last = self.rounds - 1
        lim = scoretype["W"] * last * (self.teamsize if points == "gpoints" else 1) / Decimal("2.0")
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            val = (rounds >= last) and tbscore[prefix + "acc"][last] > lim
            tbscore[prefix + "top"] = {"val": val}
        return "top"

    def compute_random(self, tb, cmps, rounds):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        for startno, cmp in cmps.items():
            tbscore = cmp["tbval"]
            for rnd in range(1, rounds + 1):
                opp = cmp["rsts"][rnd]["opponent"] if rnd in cmp["rsts"] and "opponent" in cmp["rsts"][rnd] else 0
                if opp > 0:
                    randomval = cmps[opp]["tbval"][prefix + "rnd"]["val"]
                    self.addtbval(tbscore[prefix + "rnd"], rnd, randomval)
        return "rnd"

    def get_nul(self, tb, cmps, rounds):
        return "nul"

    def get_builtin(self, tb, cmps, rounds):
        tbname = tb["name"]
        tbname = self.tiebreaklist[tbname]["name"]
        return tbname.lower()

    def reverse_pointtype(self, tb, cmps, rounds):
        txt = self.primaryscore
        trans = {
            "mpoints": "gpoints",
            "gpoints": "mpoints",
            "mmpoints": "ggpoints",
            "mgpoints": "gmpoints",
            "gmpoints": "mgpoints",
            "ggpoints":"mmgpoints"
        }
        tb["pointtype"] = trans.get(txt, txt)
        return "points"

    def parse_tiebreak(self, order, txt):
        # BH@23:IP/C1-P4F
        pointtrans = {
            "MP": "mpoints",
            "GP": "gpoints",
            "MM": "mmpoints",
            "MG": "mgpoints",
            "GM": "gmpoints",
            "GG": "ggpoints",
        }
        txt = txt.upper()
        comp = txt.replace("!", "/").replace("#", "/").split("/")
        # if len(comp) == 1:
        #    comp = txt.split('-')
        nameparts = comp[0].split(":")
        nameyear = nameparts[0].split("@")
        nameyear.append("24")
        name = nameyear[0]
        year = int(nameyear[1])
        pt = ""
        if self.primaryscore is not None:
            pointtype = self.primaryscore
        elif self.isteam:
            pointtype = "mpoints"
            pt = ":MP"
        else:
            pointtype = "points"
            pt = ""
        if name == "MPTS":
            pointtype = "mpoints"
            pt = ":MP"
        if name == "GPTS":
            pointtype = "gpoints"
            pt = ":GP"

        if len(nameparts) == 2:
            pointtype = pointtrans[nameparts[1].upper()]
            pt = ":" + pointtype
        if self.primaryscore is None and (name == "PTS" or name == "MPTS" or name == "GPTS"):
            self.primaryscore = pointtype
        # if name == 'MPVGP':
        #    name = 'PTS'
        #        pointtype = self.reverse_pointtype(self.primaryscore)
        desc = name.upper() + pt

        tb = {
            "order": order,
            "name": name,
            "desc": desc,
            "pointtype": pointtype,
            "modifiers": {
               # "cutlow": 0,                   # cut low
               # "cuthigh": 0,                  # cut high
               # "plim": Decimal("50.0"),       # KS lim in percentage
               # "nlim": Decimal("0.0"),        # KS lim in score
               # "unrated": self.unrated,       # Set unrated = <val> 
               # "urd": False,                  # D All unplayed is draw (not published) 
               # "predetermined: False,         # Treat all unplayed games as played
               # "swiss": False,                # Treat as Swiss tournament
               # "foremode": False,             # Fore mode
               # "vun": False,                  # Proposal of Roberto (not published)
               # "exchange": False,             # Exchange priamry and secondary score for tiebreak calculation (not published)
                "rev": False,                   # Reverse default order
                "ver": self.rulesversion,       # Set rule version, 1=2024, 2=2026
            },
        }
        tiebreak = self.tiebreaklist[name] if name in self.tiebreaklist else self.tiebreaklist["NUL"]
        for flag in list(tiebreak["flag"]):
            modifier =  {
                "P" : {"predetermined" : False},
                "D" : {"urd" : False},
                "U" : {"unrated" : self.unrated},
                "F" : {"foremode" : False}, 
                "C" : {"cutlow" : 0},
                "M" : {"cutlow" : 0, "cuthigh" : 0},
                "L" : {"plim" : Decimal("50.0"), "nlim" : Decimal("0.0")},
                "K" : {"nlim" : Decimal("0.0")},
            }.get(flag, {}) 
            tb["modifiers"].update(modifier)

        for mf in comp[1:]:
            mf = mf.upper()
            desc += "/" + mf
            for index in range(0, len(mf)):
                if mf[index] == "C":
                        if mf[1:].isdigit():
                            tb["modifiers"]["cutlow"] = int(mf[1:])
                elif mf[index] == "M":
                        if mf[1:].isdigit():
                            tb["modifiers"]["cutlow"] = int(mf[1:])
                            tb["modifiers"]["cuthigh"] = int(mf[1:])
                elif mf[index] == "L":
                        scale = Decimal("1.0") if "." in mf else Decimal(0.5)
                        numbers = mf.replace(".", "")
                        if mf[1:].isdigit():
                            tb["modifiers"]["plim"] = Decimal(mf[1:])
                        elif mf[1] == "+" and numbers[2:].isdigit():
                            tb["modifiers"]["nlim"] = Decimal(mf[2:]) * scale
                        elif mf[1] == "-" and numbers[2:].isdigit():
                            tb["modifiers"]["nlim"] = -Decimal(mf[2:]) * scale
                elif mf[index] == "K":
                        if mf[1:].isdigit():
                            tb["modifiers"]["nlim"] = Decimal(mf[1:])
                elif mf[index] == "D":
                        tb["modifiers"]["urd"] = True
                elif mf[index] == "U":
                        tb["modifiers"]["unrated"] = int(mf[1:])
                elif mf[index] == "P":
                        tb["modifiers"]["predetermined"] = True
                elif mf[index] == "F":
                        tb["modifiers"]["foremode"] = True
                elif mf[index] == "R":
                        tb["modifiers"]["rev"] = True
                elif mf[index] == "S":
                        tb["modifiers"]["swiss"] = True
                elif mf[index] == "X":
                        tb["modifiers"]["exchange"] = True
                elif mf[index] == "V":
                        ver = int(mf[1:]) if len(mf[1:]) else max(self.TIEBREAK_RULES.keys()) 
                        if ver > 2000:
                            ver = {2022: 0, 2024: 1, 2026:2}.get(ver, 2)
                        else:
                            ver = ver if ver == 0 or ver == 1 else 2 
                        tb["modifiers"]["ver"] = ver
                elif mf[index] == "N":
                        tb["modifiers"]["vun"] = True
        if self.rr and not tb["modifiers"].get("swiss", False):  # Default for RR is to treat unplayed games as played
            tb["modifiers"]["predetermined"] = True
        tb["desc"] = desc
        return tb

    def addval(self, cmps, tb, value):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        precision = 0
        for startno, cmp in cmps.items():
            cmp["tiebreakScore"].append(cmp["tbval"][prefix + value]["val"])
            tbdetails = {"desc": tb["desc"]}
            tbdetails.update(cmp["tbval"][prefix + value])
            cmp["tiebreakDetails"].append(tbdetails)
            val = cmp["tbval"][prefix + value]["val"]
            if isinstance(val, Decimal):
                (s, n, e) = val.as_tuple()
                if isinstance(e, int):
                    precision = min(precision, e)
        tb["precision"] = -precision

    # -------------------------------
    # Average
    
    def compute_average_of_buchholz(self, tb, cmps, rounds):
        if rounds < 9:
            norm = "0.01"  # 2 decimals holds for 8 rounds
        elif rounds < 27:
            norm = "0.001"  # 3 decimals holds for 26 rounds    
        elif rounds < 73:
            norm = "0.0001"  # 4 decimals holds for 73 rounds    
        else:
            norm = "0.00001"  # 5 decimals holds for dont know how many rounds       
        tbname = self.compute_buchholz_sonneborn_berger(tb, cmps, rounds)
        tbname = self.compute_average(tb, "bh", cmps, rounds, False, norm)  # 0.001 => 3 decimals holds for 26 rounds
        return tbname

    def compute_average_rating_performance(self, tb, cmps, rounds):
        tbname = self.compute_ratingperformance(tb, cmps, rounds)
        tbname = self.compute_average(tb, "tpr", cmps, rounds, False, "1.") # 1.0 => no decimals
        return tbname

    def compute_average_perfect_performance(self, tb, cmps, rounds):
        tbname = self.compute_ratingperformance(tb, cmps, rounds)
        tbname = self.compute_average(tb, "ptp", cmps, self.currentround, False, "1.") # 1.0 => no decimals
        return tbname



    def compute_average(self, tb, name, cmps, rounds, ignorezero, norm):
        (scorename, points, scoretype, prefix) = self.get_scoreinfo(tb, True)
        tbname = tb["name"].lower()
        for startno, cmp in cmps.items():
            cmp["tbval"][prefix + tbname] = {"val": 0, "cut": []}
            sum = Decimal(0.0)
            num = 0
            for rnd, rst in cmp["rsts"].items():
                if rst["played"] and rst["opponent"] > 0 and rnd <= rounds:
                    opponent = rst["opponent"]
                    value = cmps[opponent]["tbval"][prefix + name]["val"]
                    if value is not None:
                        num += 1
                        sum += value
                        self.addtbval(cmp["tbval"][prefix + tbname], rnd, value)
            val = sum / Decimal(num) if num > 0 else None
            cmp["tbval"][prefix + tbname]["val"] = val.quantize(Decimal(norm), rounding=ROUND_HALF_UP) if val else val
        return tbname

    # get_scoreinfo(self, tb, primary)
    # tb - tiebreak
    # primary or secondary score

    def get_scoreinfo(self, tb, primary):
        if tb["modifiers"].get("exchange", False):
            primary = not primary
        pos = 0 if primary else 1
        key = tb["pointtype"][pos]
        if not primary and (key != "g" and key != "m"):
            key = tb["pointtype"][0]
            if key == "g":
                key = "m"
            elif key == "m":
                key = "g"
        if key == "g":
                return ["game", "gpoints", self.gamescore, "gpoints_"]
        elif key == "m":
                return ["match", "mpoints", self.matchscore, "mpoints_"]
        else:
                return ["game", "points", self.gamescore, "points_"]
