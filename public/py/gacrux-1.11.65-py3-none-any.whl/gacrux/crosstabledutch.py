# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 07:39:55 2025
@author: Otto Milvang, sjakk@milvang.no

The main purpose of crosstable is to work on the structures
competitors - One-dimentional array of size [0..P+1] of competitor objects 
opponents - Two-dimentional array of size [0..P+1][0..P+1] of opponent objects 


"""

from itertools import combinations  
from enum import Enum
from decimal import Decimal

if __name__[:7] == "gacrux." or __package__ is not None and __package__ == "gacrux":
    from gacrux.crosstable import crosstable, flt
    from gacrux.tiebreak import tiebreak
    from gacrux.gacruxexeptions import GacruxInvariantError
else:
    from crosstable import crosstable, flt
    from tiebreak import tiebreak
    from gacruxexeptions import GacruxInvariantError


class qdefs(Enum):
    QC6 = 0
    QC7 = 1
    QN8 = 2
    QC8 = 3
    QC9 = 4
    QMM = 5
    QC10 = 6
    QC11 = 7
    QC12 = 8
    QC13 = 9
    QC14 = 10
    QC15 = 11
    QC16 = 12
    QC17 = 13
    QC18 = 14
    QC19 = 15
    QC20 = 16
    QC21 = 17
    HE1 = 18
    HE2 = 19
    HO1 = 20
    HO2 = 21
    HO3 = 22
    HO4 = 23
    HO5 = 24
    IW = 25
    QL = 26
    QC0 = 26
    HE0 = 27
    HO0 = 28
    B0 = 29
    QS = 30


# Euality constants
QC6 = qdefs.QC6.name
QC7 = qdefs.QC7.name
QN8 = qdefs.QN8.name
QC8 = qdefs.QC8.name
QC9 = qdefs.QC9.name
QMM = qdefs.QMM.name
QC10 = qdefs.QC10.name
QC11 = qdefs.QC11.name
QC12 = qdefs.QC12.name
QC13 = qdefs.QC13.name
QC14 = qdefs.QC14.name
QC15 = qdefs.QC15.name
QC16 = qdefs.QC16.name
QC17 = qdefs.QC17.name
QC18 = qdefs.QC18.name
QC19 = qdefs.QC19.name
QC20 = qdefs.QC20.name
QC21 = qdefs.QC21.name
HE1 = qdefs.HE1.name
HE2 = qdefs.HE2.name
HO1 = qdefs.HO1.name
HO2 = qdefs.HO2.name
HO3 = qdefs.HO3.name
HO4 = qdefs.HO4.name
HO5 = qdefs.HO5.name
IW = qdefs.IW.name
QL = qdefs.QL.value
QC0 = qdefs.QC0.name
HE0 = qdefs.HE0.name
HO0 = qdefs.HO0.name
B0 = qdefs.B0.name
QS = qdefs.QS.value


class crosstable_dutch(crosstable):
    """
    init_crosstable / update crosstable
        Update competitors first from cmps[i]['tiebreakDetails']
        The crosstable is an virtual crosstable of  elements.
        A game between player a and b is described in the crosstable elsement self.cmps[a][b] === self.cmps[b][a]
        init_crosstable updates:
            For all pairs in the crosstable
            canmeet - True if they are alowd to meet, False othewise
            played - Number of times they have met
            psd - The differnce in score between the palyers in 0.5p as char in base36, (or 'Z' for more than 17p).
        update_crosstable updates:
            For all pairs in a scorebracket
            c10 - c21 - The rules

    C = log10 (Max competitors) = 3
    R = log10 (Max rounds) = 2
    M = Number of moved down players
    P = Max point difference on downfloaters (in scorelevels)
    N = Number of moved down players + number of downfloaters
    B = Len of BSB
    S = Max pairs that can be paired


    """

    # constructor function
    def __init__(self, experimental, checkonly, verbose):
        super().__init__(experimental, checkonly, verbose)
        self.scalars = [QC6, QN8, QC9, QC10, QC11, QC12, QC13, QC14, QC15, QC16, QC17, HO1, HO2, IW]

    def floatrule(self):
        return "FLTD"

    def maxquality(self):
        return qdefs.IW.value

    """
    color_preference - C.04.3 art. 1.7

    The definition, the strengths it returns and the decision about which article wins
    when several fit are in colourpreference.py, which the tie-break listing (the COP
    column of tiebreak.compute_score) reads too, so that the engine and the listing
    cannot disagree about the same player. This is the engine's handle on it.

    The return is the colour, then the strength:
    "w2" / "b2" - an absolute colour preference, art. 1.7.1
    "w1" / "b1" - a strong colour preference, art. 1.7.2
    "w0" / "b0" - a mild colour preference, art. 1.7.3
    "nc"        - no colour preference, art. 1.7.4

    The colour difference (cod) is C.04.3 art. 1.6, games played with White minus games played
    with Black; the colour sequence (csq) is the colours of the games played, in order. Only
    played games count in either (C.04.2 art. 3.4), and that is the caller's business: both
    callers build cod and csq from played games with an opponent before asking.

    The definitions of art. 1.7 are not mutually exclusive and the article does not say which
    one wins when more than one fits. A player who has played Black, Black, White, White has a
    colour difference of zero and had White in the two latest rounds, so

        1.7.1  an absolute preference "when a player's colour difference is greater than +1
            or less than -1, or when a player had the same colour in the two latest rounds
            they played"
        1.7.3  a mild preference "when a player's colour difference is zero, the preference
            being to alternate the colour with respect to the previous game they played"

    both apply. They agree on the colour - Black - and disagree on its strength, and the
    strength is what allocates the game: art. 5.2.2 is "grant the stronger colour preference".
    Pair that player, a topscorer so that [C3] does not keep the two apart, against one whose
    sequence is a bye, White, Black, White - colour difference +1, a strong preference for
    Black by art. 1.7.2 - and the two readings of 1.7 hand Black to different players.

    This module takes a player's colour preference to be the first definition in art. 1.7
    that fits them, so the Black-Black-White-White player has an absolute preference and
    takes Black.

    The article carries the reading itself. It defines the three strengths in a fixed order
    and gives no rule for choosing between them, which leaves the order they are written in as
    the only ranking the text supplies; and art. 1.7.2 reads as though the case art. 1.7.1
    already took is meant to be out of it, since a player with the same colour twice running
    is not a player whose colour is merely leaning one way. Read that way the conflict is a
    drafting accident - art. 1.7.2 would say what it means if it read "A strong colour
    preference occurs when a player does not have an absolute colour preference and their
    colour difference is +1 (preference for Black) or -1 (preference for White)". If the
    Dutch rules are redrafted to rank the definitions the other way, this is the chain to
    change.

    The chain below is that order, and it is the order the engine has always used - the art.
    1.7.1 tests come before the art. 1.7.2 ones, which come before art. 1.7.3. C.04.6 has the
    same shape of conflict in its own art. 1.7.2 and the same order settles it, but the team
    strengths differ, so crosstable_fideteam keeps a colour preference of its own.

    """

    def color_preference(self, cod, csq):
        """The colour preference of a player with colour difference *cod* and history *csq*."""
        # C.04.3 art. 1.7.1: "The preference is for White when the colour difference is less
        # than -1 OR when the last two games were played with Black." The second clause is
        # unconditional on the colour difference. Gating it at cod <= 0 (resp. cod >= 0) drops
        # the |cod| == 1 cases, which then fall through to art. 1.7.2 and come back as a STRONG
        # preference for the OPPOSITE colour -- e.g. a player with the colour history wwwbb
        # (cod = +1, last two Black) has an absolute preference for White by 1.7.1, but was
        # returned "b1". Widening to cod <= 1 / cod >= -1 covers them.
        #
        # cod >= +2 with the last two games Black (and its mirror) is left resolving by the
        # colour difference, as before: there art. 1.7.1 asserts BOTH preferences, and the
        # article does not say which wins.
        if cod <= -2 or cod <= 1 and csq[-2:] == "bb":
            return "w2"
        elif cod >= 2 or cod >= -1 and csq[-2:] == "ww":
            return "b2"
        elif cod == -1:
            return "w1"
        elif cod == 1:
            return "b1"
        elif csq[-1:] == "b":
            return "w0"
        elif csq[-1:] == "w":
            return "b0"
        return "nc"


    """
    update crosstable
        Update competitors first from cmps[i]['tiebreakDetails']
        update_crosstable updates:
            For all pairs in a scorebracket
            c10 - c21 - The rules


    """

    def update_crosstable(self, scorelevel, nodes, edges, pablevel, update_maxpsd=True):
        self.pablevel = pablevel
        if update_maxpsd:
            maxpsd = max([node["scorelevel"] for node in nodes]) - scorelevel
            self.maxpsd = nodes[0]["scorelevel"] - scorelevel
            if maxpsd != self.maxpsd:
                raise GacruxInvariantError(
                    "score bracket " + str(scorelevel) + ": the competitors are not ordered by score."
                    + " The highest score difference in the bracket is " + str(maxpsd) + ", but the first"
                    + " competitor has " + str(self.maxpsd) + ". mdp and the C-weights are indexed on the"
                    + " assumption that the first competitor is the highest one"
                )
            self.mdp = [0] * self.maxpsd
            for node in nodes:
                psd = node["scorelevel"] - scorelevel
                if psd <= 0:
                    break
                self.mdp[self.maxpsd - psd] += 1
            self.init_cweights(scorelevel, nodes)
        self.L = self.maxpsd
        # print("Update scorelevel", scorelevel, len(nodes), len(edges), pablevel, update_maxpsd, self.maxpsd)
            
  
    def update_canmeet(self, edge, a, b, bhasmet):
        # QC3 not-topscorers with absolute color preference cannot meet
        played = bhasmet.count(a["cid"]) if bhasmet is not None else 0
        ca = a["cid"]
        cb = b["cid"]
        if self.checkonly:
            hb = b.get("hst", {}).get("val", "N")
            canmeet = hb not in ["", "N"] and int(hb[0:-1]) == a["cid"]
        else:    
            canmeet = played < self.maxmeets and ca != cb and a["rfp"] and b["rfp"] or ca < self.BLOB and cb == self.BLOB
            for col in ["w", "b"]:
                col2 = col + "2"
                # C.04.3 art. 2.1.3 [C3]: two players holding an ABSOLUTE
                # same-colour preference (art. 1.7.1, cop == col2) may not be
                # paired together. A merely STRONG preference (art. 1.7.2)
                # does not carry this restriction, however large the other
                # player's own colour difference is -- there used to be a
                # second test here, "a['cod'] * b['cod'] >= 4", that forbade
                # a pairing whenever one side's |cod| was 4 or worse even if
                # the other side's preference was only strong. That treated a
                # strong preference as if it were absolute and had no article
                # behind it; it could delete the one legal edge a bracket
                # needed; see tests/test_strong_preference_may_meet_absolute.py.
                if a["cop"] == col2 and b["cop"] == col2 and (not a["top"]) and (not b["top"]):
                    canmeet = False
        # score diff
        return canmeet
          
    def update_edge(self, edge):
        c = edge
        if c["qlevel"] == self.scorelevel and c["cb"] < self.BLOB:
            return
        c["qlevel"] = self.scorelevel
        c["quality"] = {q.name : None for q in qdefs if q.value < QL}
        coltrans = {"nc": "n", "w0": "w", "w1": "W", "w2": "W", "b0": "b", "b1": "B", "b2": "B"}
        maxpsd = self.maxpsd
        scorelevel = self.scorelevel
        if c["canmeet"]:
            a = self.competitors[c["ca"]]
            b = self.competitors[c["cb"]]
            weight = self.weight
            cweight = 0
            if a["scorelevel"] < b["scorelevel"]:
                (a, b) = (b, a)
            q = c["quality"]
            q[QC6] = 0
            q[QC7] = [0] * (maxpsd)
            q[QN8] = 0
            q[QC8] = [0] * (maxpsd + 1)
            q[QC9] = 0
            q[QMM] = [0] * (self.maxmeets-1)
            for elem in range(qdefs.QC10.value, qdefs.QC18.value):
                q[qdefs(elem).name] = 0
            for elem in range(qdefs.QC18.value, qdefs.QC21.value + 1):
                q[qdefs(elem).name] = [0] * maxpsd

            level = a["scorelevel"] - scorelevel

            c14 = c15 = c16 = c17 = 0
            if a["scorelevel"] >= scorelevel and b["scorelevel"] == scorelevel:
                if self.pablevel and b["scorelevel"] == 0:
                    q[QC9] = self.rnd - 1 - a["num"].get("val", 0)
                    cweight += weight[QC9] * q[QC9]

                if c["canmeet"] and c["played"] > 0 and self.maxmeets > 1:
                    q[QMM][c["played"]-1] = 1  

                # Topscorere

                if (a["top"] or b["top"]) and a["cid"] > 0 and b["cid"] > 0:
                    # if scorelevel == 9 and a["cid"] ==3 and b["cid"] == 9: breakpoint()

                    # c10 minimize the number of topscorers who get color diff > +2 or < -2
                    # print(c, a['cod'], b['cod'])
                    # apf = a["cod"] + 1 if a["cid"] == c["w"] else a["cod"] - 1
                    # bpf = b["cod"] + 1 if b["cid"] == c["w"] else b["cod"] - 1
                    # q[QC10] = 1 if abs(apf) > 2 and abs(bpf) >= 2 or abs(apf) >= 2 and abs(bpf) > 2 else 0

                    acod = a["cod"]
                    bcod = b["cod"]
                    if acod == bcod and abs(acod) >= 2:
                        q[QC10] = 1
                        cweight += weight[QC10]

                    # c11 minimize the number of topscorers who get same color three times in a row
                    # asq = a["csq"][-2:] + ("w" if a["cid"] == c["w"] else "b")
                    # bsq = b["csq"][-2:] + ("w" if b["cid"] == c["w"] else "b")
                    acop = a["cop"]
                    bcop = b["cop"]

                    # `opp` used to be computed here as well, from a table with no entry for a
                    # competitor who has NO colour preference:
                    #
                    #     opp = {"w": "bb", "b": "ww", " ": "nc"}[acop[0]]
                    #
                    # color_preference() returns "nc" for exactly that competitor -- one with no
                    # played games at all, which a small field with byes or forfeits reaches by
                    # the third round -- so acop[0] is "n", the table has no "n", and the pairing
                    # died with KeyError: 'n'.
                    #
                    # The value was never used. It is read only inside the branch below, which
                    # cannot be entered unless acop[0] is "w" or "b", and which recomputes it from
                    # a two-entry table anyway. So the line computed a value it did not need, and
                    # crashed the engine doing it, on a legal tournament.
                    if acop[0] == bcop[0] == "w" or acop[0] == bcop[0] == "b":
                        opp = {"w": "bb", "b":"ww"}[acop[0]]
                        anp = int(acop[1])
                        bnp = int(bcop[1])

                        if a["csq"][-2:] == b["csq"][-2:] and (a["csq"][-2:] == "ww" or b["csq"][-2:] == "bb") or \
                           anp > bnp and b["csq"][-2:] == opp or bnp > anp and a["csq"][-2:] == opp or \
                           (anp == bnp == 2 and (abs(acod) > abs(bcod) and b["csq"][-2:] == opp or abs(bcod) > abs(acod) and a["csq"][-2:] == opp)):
                            q[QC11] = 1
                            cweight += weight[QC11]

                    if scorelevel == -1:
                         print(f"A: {a['cid']:2} {a['cod']:2} {a['csq'][-2:]} {a['cop']},   B: {b['cid']:2} {b['cod']:2} {b['csq'][-2:]} {b['cop']},  Q10: {q[QC10]} Q11: {q[QC11]}")


                # c12 minimize the number of players who do not get their color preference
                if a["cop"] != "nc" and a["cop"][0].lower() == b["cop"][0].lower():
                    q[QC12] = 1
                    cweight += weight[QC12]

                # c13 minimize the number of players who do not get their strong color preference
                if q[QC12] == 1 and int(a["cop"][1]) > 0 and int(b["cop"][1]) > 0:
                    q[QC13] = 1
                    cweight += weight[QC13]

                c["colordiff"] = coltrans.get(a["cop"], a["cop"][0].upper()) + coltrans.get(b["cop"], b["cop"][0].upper())

                # c15 minimize the number of players who receive upfloft in the previous round
                c15 = 1 if (a["acc"] < b["acc"]) and (a["flt"] & flt.UF1.value) or (a["acc"] > b["acc"]) and (b["flt"] & flt.UF1.value) else 0
                if c15:
                    q[QC15] = 1
                    cweight += weight[QC15]

                # c17 minimize the number of players who receive upfloft two rounds before
                c17 = 1 if (a["acc"] < b["acc"]) and (a["flt"] & flt.UF2.value) or (a["acc"] > b["acc"]) and (b["flt"] & flt.UF2.value) else 0
                if c17:
                    q[QC17] = 1
                    cweight += weight[QC17]

            elif a["scorelevel"] >= scorelevel and b["scorelevel"] < scorelevel:
                q[QC6] = 1
                cweight += weight[QC6]
                if level > 0:
                    # q[QC7] = [1 if level == maxpsd - i else 0 for i in range(maxpsd)]
                    q[QC7][maxpsd - level] = 1
                    cweight += weight[QC7][maxpsd - level]

                if self.pablevel and b["scorelevel"] == 0:
                    q[QC9] = self.rnd - 1 - a["num"].get("val", 0)
                    cweight += weight[QC9] * q[QC9]

                # c14 minimize the number of players who receive downfloat in the previous round
                c14 = 1 if (a["flt"] & flt.DF1.value) else 0
                if c14 and scorelevel == a["scorelevel"]:
                    q[QC14] = 1
                    cweight += weight[QC14]

                # c16 minimize the number of players who receive downfloat two rounds before
                c16 = 1 if a["flt"] & flt.DF2.value else 0
                if c16 and scorelevel == a["scorelevel"]:
                    q[QC16] = 1
                    cweight += weight[QC16]

            # c18-21 minimize the score difference of players who receive downfloat/upfloat in the previous round
            for cnn, val in enumerate([(level if cxx else 0) for cxx in [c14, c15, c16, c17]], start=qdefs.QC18.value):
                if val > 0:
                    q[qdefs(cnn).name][maxpsd - val] = 1
                    cweight += weight[qdefs(cnn).name][maxpsd - val]

            scorelevel2 = scorelevel - 1
            # print("QN8", scorelevel2, a['cid'], b['cid'], a['scorelevel'], b['scorelevel'], "            ", a['scorelevel'] >= scorelevel2 and b['scorelevel'] < scorelevel2)
            # if scorelevel == testlevel and update_maxpsd:
            #    breakpoint()
            if a["scorelevel"] >= scorelevel2 and b["scorelevel"] < scorelevel2:
                q[QN8] = 1
                cweight += weight[QN8]
                level = max(a["scorelevel"], b["scorelevel"]) - scorelevel2
                if level > 0:
                    # q[QC8] = [1 if level == maxpsd + 1 - i else 0 for i in range(maxpsd+1)]
                    q[QC8][maxpsd + 1 - level] = 1
                    cweight += weight[QC8][maxpsd + 1 - level]

            c["qc"] = (q[QC9] + sum(q[QMM]) + q[QC10] + q[QC11] + q[QC14] + q[QC15] + q[QC16]+ q[QC17] \
                    + sum(q[QC18]) + sum(q[QC19]) + sum(q[QC20]) + sum(q[QC21])) == 0
            c["qcweight"] = cweight

    def update_hetrogenious(self, scorelevel, nodes, edges, bsn):
        M = self.M = sum(self.mdp)
        self.ilen = 0
        elen = len(bsn) + 1
        weight = self.weight
        self.init_heweights(scorelevel, bsn)
        for c in edges:
            (ca, cb) = (c["ca"], c["cb"])
            q = self.get_edge_quality(c)["quality"]
            q[HE1] = [0] * M
            q[HE2] = [0] * M
            heweight = 0
            e1weight = sum(weight[HE1])

            ascl = self.competitors[ca]["scorelevel"]
            bscl = self.competitors[cb]["scorelevel"]
            absn = bsn.get(ca, elen)
            bbsn = bsn.get(cb, elen)
            if absn > bbsn:
                (absn, bbsn, ascl, bscl) = (bbsn, absn, bscl, ascl)
            # print(self.competitors[ca])
            if ascl > scorelevel and bscl <= scorelevel:
                e0 = absn
                e1 = 1 if bbsn == elen else 0
                e2 = bbsn - M if bbsn < elen else 0
                #if bscl < scorelevel: breakpoint()
                q[HE1][e0-1] = e1
                q[HE2][e0-1] = e2
                heweight += weight[HE1][e0 - 1] * e1
                heweight += weight[HE2][e0-1] * e2

            c["heweight"] = heweight

    def update_homogenious(self, scorelevel, edges, bsn, S):
        B = self.B = len(bsn)
        mdp = B - 2 * S
        B3 = self.B3 = S
        B4 = self.B4 = B - S
        B5 = self.B5 = B - 1
        self.ilen = 0
        # print ("BO:", B, S)
        weight = self.weight
        self.init_howeights(scorelevel, S, mdp)
        # print("CheckAnlyse", scorelevel, "M="+str(M), "P="+str(P), "N="+str(N), "S="+str(S), "B="+str(B) )
        # HO4weight = sum([weight[HO4][i] for i in range(B4)])
        HO4weight = sum(weight[HO4])
        for c in edges:
            c["howeight"] = 0
            (ca, cb) = (c["ca"], c["cb"])
            q = self.get_edge_quality(c)["quality"]
            q[HO1] = 0
            q[HO2] = 0
            q[HO3] = [0] * B3
            q[HO4] = [1] * B4
            q[HO5] = [0] * B5
            howeight = HO4weight
            ascl = self.competitors[ca]["scorelevel"]
            bscl = self.competitors[cb]["scorelevel"]
            if ascl == scorelevel and bscl == scorelevel:
                absn = bsn[ca]
                bbsn = bsn[cb]
                if absn > bbsn:
                    (absn, bbsn, ascl, bscl) = (bbsn, absn, bscl, ascl)

                if c["canmeet"]:
                    if absn > S:
                        q[HO1] = 1
                        howeight += weight[HO1]
                    q[HO2] = absn - 1
                    howeight += (absn - 1) * weight[HO2]
                    if absn <= S:
                        q[HO3][S - absn] = 1
                        howeight += weight[HO3][S - absn]
                    else:
                        q[HO4][absn - S - 1] = 0
                        howeight -= weight[HO4][absn - S - 1]
                    q[HO5][absn - 1] = bbsn - absn
                    howeight += weight[HO5][absn - 1] * (bbsn - absn)
                    # if c['quality'][HO5] != [bbsn if absn == i+1 else 0 for i in range(B)]: breakpoint()
            c["howeight"] = howeight

    def update_bipartite(self, scorelevel, pairs, bsn, HO2start, HO2stop):
        B = self.B = len(bsn)
        H = self.H = len(bsn) // 2
        M = self.M = sum(self.mdp)
       # print ("BO:", B, S, self.S)

        # print("CheckAnlyse", scorelevel, "M="+str(M), "P="+str(P), "N="+str(N), "S="+str(S), "B="+str(B) )
        self.init_bweights(scorelevel, H)
        weight = self.weight
        for pno, pair in enumerate(pairs):
            (ca, cb) = pair
            bweight = 0
            if HO2start <= ca <= HO2stop:
                (ca, cb) = (cb, ca)
            c = self.get_edge_quality(self.opponents[ca][cb])
            q = c["quality"]
            if q[HE1] is None or len(q[HE1]) != M:
                q[HE1] = [0] * M
                q[HE2] = [0] * M
            q[HO1] = 0
            q[HO2] = 0
            q[HO3] = 0
            q[HO4] = 0
            q[HO5] = [0] * H
            if pno >= mdp:
                absn = pno - mdp
                bbsn = bsn[cb]
                q[HO5][absn] = bbsn -absn
                bweight = weight[HO5][absn] * (bbsn - absn)
            c["biweight"] = bweight

    # Compute weight
    # mode 'E' - Hetrogenous
    # mode 'S' - Homogenous
    # mode 'B' - Bipartite
    # mode 'A' - Add S-part

    def cascade_weights(self, depth, start, stop):
        w = 1
        acc = {QC6: QC0, HE1: HE0, HO1: HO0}
        let = {QC6: "C", HE1: "HE", HO1: "HO"}
        # print("Deights", let[start], self.depth[start:stop+1])
        weight = self.weight
        for cval in range(stop.value, start.value-1, -1):
            nval = qdefs(cval).name
            if isinstance(depth[nval], int):
                (w, weight[nval], depth[nval]) = (w*depth[nval], w, len(str(depth[nval])))
            elif isinstance(depth[nval], list):
                weight[nval] = [0]*len(depth[nval])
                for eval in range(len(weight[nval])-1, -1, -1):
                    (w, weight[nval][eval], depth[nval][eval]) = (w*depth[nval][eval], w, len(str(weight[nval][eval])))
            else:
                raise GacruxInvariantError(
                    "criterion " + str(nval) + " has a depth of type " + type(depth[nval]).__name__
                    + ", but a weight can only be cascaded over an int or a list of int"
                )
        # print("Weights", let[start], self.weight[acc[start]], self.weight[start:stop+1])
        return w



    def init_cweights(self, scorelevel, nodes):
        # print(f"Init cweight, scorelevel: {scorelevel}")
        cc = len(nodes) + 1
        c7len = len(self.mdp)
        c8len = c7len + 1
        mmlen = self.maxmeets -1
        self.weight = weight = {q.name : 0 for q in qdefs}
        self.depth  = depth  = {q.name : 0 for q in qdefs}
        scoregroup = [node for node in nodes if node["scorelevel"] >= scorelevel] 
        nscoregroup = [node for node in nodes if node["scorelevel"] >= scorelevel-1] 
        bsize = len(scoregroup)
        depth[QC6] = bsize +1
        depth[QC7] = [psd + 1 for psd in self.mdp ]
        depth[QN8] = len(nscoregroup) + 1
        depth[QC8] = [psd + 1 for psd in self.mdp ] + [bsize + 1 - sum(self.mdp) ] 
        depth[QC9] = bsize + 1 if scorelevel <= self.pablevel else 1
        depth[QMM] = [cc] * mmlen
        for i in range(mmlen):  
            depth[QMM][i] = cc
        depth[QC10] = len([node for node in nodes if node["scorelevel"] >= scorelevel and node["top"]]) +1
        depth[QC11] = depth[QC10]
        depth[QC12] = cc
        depth[QC13] = cc
        depth[QC14] = len([node for node in nodes if node["scorelevel"] >= scorelevel and (node["flt"] & flt.DF1.value)]) +1
        depth[QC15] = len([node for node in nodes if node["scorelevel"] <= scorelevel and (node["flt"] & flt.UF1.value)]) +1
        depth[QC16] = len([node for node in nodes if node["scorelevel"] >= scorelevel and (node["flt"] & flt.DF2.value)]) +1
        depth[QC17] = len([node for node in nodes if node["scorelevel"] <= scorelevel and (node["flt"] & flt.UF2.value)]) +1
        depth[QC18] = [psd + 1 for psd in self.mdp ]
        depth[QC19] = [psd + 1 for psd in self.mdp ]
        depth[QC20] = [psd + 1 for psd in self.mdp ]
        depth[QC21] = [psd + 1 for psd in self.mdp ]
        # print(scorelevel, depth)
        weight[QC0] = self.cascade_weights(depth, qdefs.QC6, qdefs.QC21)

        self.QCweight = (
            "C 1--"
            + "0"  # QC6
            + "-"
            + str(["0" for v in [0] * c7len]).replace("'", "")  # QC7
            + "-"
            + "0"  # QN8
            + "-"
            + str(["0" for v in [0] * c8len]).replace("'", "")  # QC8
            + "-"
            + "0"  # QC9
            + "-"
            + str(["0" for v in [0] * mmlen]).replace("'", "")  # QMM
            + "-"
            + "0"  # QC10
            + "-"
            + "0"  # QC11
            + "-"
            + "0"  # QC12
            + "-"
            + "0"  # QC13
            + "--"
            + "0"  # QC14
            + "-"
            + "0"  # QC15
            + "-"
            + "0"  # QC16
            + "-"
            + "0"  # QC17
            + "--"
            + str(["0" for v in [0] * c7len]).replace("'", "")  # QC18
            + "-"
            + str(["0" for v in [0] * c7len]).replace("'", "")  # QC18
            + "-"
            + str(["0" for v in [0] * c7len]).replace("'", "")  # QC20
            + "-"
            + str(["0" for v in [0] * c7len]).replace("'", "")
        )  # QC21

 


    def init_heweights(self, scorelevel, bsn):
        # print(f"Init heweight, scorelevel: {scorelevel}")
        M = self.M
        elen = len(bsn) + 1 - M
        weight = self.weight
        depth = self.depth
        depth[HE1] = [2] * M
        depth[HE2] = [elen] * M
        weight[HE0] = self.cascade_weights(depth, qdefs.HE1, qdefs.HE2)
        self.HEweight = "E 1--" + str(["0" for v in [0] * M]).replace("'", "") + "-" + str(["0" for v in [0] * M]).replace("'", "")


    def init_howeights(self, scorelevel, S, mdp):
        # print(f"Init howeight, scorelevel: {scorelevel}")
        B = self.B # len of BSN
        B3 = self.B3
        B4 = self.B4
        B5 = self.B5
        weight = self.weight
        depth = self.depth

        depth[HO1] = S + 1
        depth[HO2] = sum(list(range(B-1, S, -2)[:S])) + 1 # B-1 + B-3 + ... + B-(2*S-1) + 1, first S odd numbers starting from B-1 
        depth[HO3] = [2] * B3
        depth[HO4] = [2] * B4
        depth[HO5] = list(range(B5, 0, -1))
        weight[HO0] = self.cascade_weights(depth, qdefs.HO1, qdefs.HO5)
 
        self.HOweight = (
            "S 1--"
            + "0"
            + "-"
            + "0"
            + "-"
            + str(["0" for v in [0] * B3]).replace("'", "")
            + "-"
            + str(["0" for v in [0] * B4]).replace("'", "")
            + "-"
            + str(["0" for v in [0] * B5]).replace("'", "")
        )




    def init_bweights(self, scorelevel, HO2nodes):
        #print(f"Init bweight, scorelevel: {scorelevel}")
        B = self.B
        H = self.H = HO2nodes
        weight = self.weight
        depth = self.depth
        depth[HO5] = [B + 1] * H
        weight[HO0] = self.cascade_weights(depth, qdefs.HO1, qdefs.HO5)
        self.Bweight = "B 1--" + str(["0" for v in [0] * H]).replace("'", "")

    def update_weight(self, mode, category, c):
        # match (mode):
        if mode == "QC":
                weight = c["qcweight"]
        elif mode == "HE":
                weight = c["qcweight"] * self.weight[HE0] + c["heweight"]
        elif mode == "HO":
                weight = c["qcweight"] * self.weight[HO0] + c["howeight"]
        elif mode == "BI":
                weight = c["qcweight"] * self.weight[B0] + c["biweight"]
        else:
            raise GacruxInvariantError("unknown weight mode " + str(mode))
        c["mode"] = mode
        c["levels"] = category
        c["weight"] = weight
        return weight

    def compute_weight(self, wpairs, bquality):

        quality = {q.name : None for q in qdefs if q.value < QL}
        quality[QN8] = 0

        # down =  [d[0] for d in downfloaters]
        for c in wpairs:
            # print(c['ca'], c['cb'], c['quality'][QN8])
            
            self.get_edge_quality(c)
            q = c["quality"]
            for elem in range(QL):
                nelem = qdefs(elem).name
                if elem < qdefs.HE1.value or (c.get("mode", "") == "HE" and elem < qdefs.HO1.value) or (c.get("mode", "") == "HO" and elem >= qdefs.HO1.value):
                    if q[nelem] is None:
                        pass
                    elif quality[nelem] is None:
                        quality[nelem] = q[nelem]
                    elif isinstance(quality[nelem], int):
                        quality[nelem] += q[nelem]
                    else:
                        for i in range(len(quality[nelem])):
                            quality[nelem][i] += q[nelem][i]

        return quality


    def format_weight(self, mode, w):
        weight = self.weight
        f = self.QCweight
        # match (mode):
        if mode == "HE":
                f += " " + self.HEweight
                cw = w // weight[HE0]
                ew = w % weight[HE0]
                return self.format_wpart(self.QCweight, cw, qdefs.QC6, qdefs.QC21) + " " + self.format_wpart(self.HEweight, ew, qdefs.HE1, qdefs.HE2)
        elif mode == "HO":
                f += " " + self.HOweight
                cw = w // weight[HO0]
                sw = w % weight[HO0]
                return self.format_wpart(self.QCweight, cw, qdefs.QC6, qdefs.QC21) + " " + self.format_wpart(self.HOweight, sw, qdefs.HO1, qdefs.HO5)
        elif mode == "BI":
                f += " " + self.Bweight
                cw = w // weight[B0]
                bw = w % weight[B0]
                return self.format_wpart(self.QCweight, cw, qdefs.QC6, qdefs.QC21) + " " + self.format_wpart(self.Bweight, bw, qdefs.HO5, qdefs.HO5)
        else:
                cw = w
                return self.format_wpart(self.QCweight, cw, qdefs.QC6, qdefs.QC21)


    def compute_pab_weight(self, edges):
        for edge in edges:
            edge["weight"] = edge["sb"] if edge["ca"] == 0 else 0

