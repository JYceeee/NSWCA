# -*- coding: utf-8 -*-
# noqa
"""
Copyright 2024, Otto Milvang
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Created on Mon Aug  7 16:48:53 2023
@author: Otto Milvang, sjakk@milvang.no
"""
import sys
import time

from collections import defaultdict


if __name__[:7] == "gacrux." or __package__ is not None and __package__ == "gacrux":
    from gacrux import version
    from gacrux import pairingdutch
    from gacrux import helpers
    from gacrux.chessjson import chessjson
    from gacrux.commonmain import commonmain
    from gacrux.tiebreak import tiebreak
    from gacrux.pairing import pairing
    from gacrux.pairingdutch import pairing_dutch
    from gacrux.pairingberger import pairing_berger
    from gacrux.gacruxexeptions import GacruxNoLegalPairing
    from gacrux.pairingfideteam import pairing_fideteam
    from gacrux.trf2json import trf2json
else:
    import version
    import pairingdutch
    import helpers
    from chessjson import chessjson
    from commonmain import commonmain
    from tiebreak import tiebreak
    from pairing import pairing
    from pairingdutch import pairing_dutch
    from pairingberger import pairing_berger
    from gacruxexeptions import GacruxNoLegalPairing
    from pairingfideteam import pairing_fideteam
    from trf2json import trf2json


AHEAD = "  Tournament analysis   "
PHEAD = "  Checker pairing       "

# ==============================


class pairingchecker(commonmain):
    """
    Method: common_main():
    python pairingchecker.py [options]
        -i input-file        # default is stdin
        -o output-file       # default is stdout
        -f TRF | TS | JSON   # use extention
        -e <eventno>         # default is 1, TRF has one event / file
        -b ascii | utf8 | latin1
        -t w | b             # initial color on top ranked player in round 1
        -u [list of illagal pairings]
        -n <no>              # Round to pair, default next round, or all rounds in check mode
        -m <method>          # dutch | berger | fideteam[-typea | -typeb | -nocolor]
        -c                   # check mode, look if tournament pairing is correct
        -a                   # Analysis and show tournament pairing
        -p                   # Dhow the correct pairing of next round (or another round with -n)
        -c [-a] [-p]         # Show correct pairing and explain tournament pairing / checker pairing
        -d @ | T | J         # Print result in result format, text format or JSON formet (default)


    --- Return object ---
        {
         "filetype": "Pairing",
         "version": "1.0",
         "origin": "pairingchecker ver. 1.00",
         "published": "2025-04-14 16:42:21",
         "status": {
             "code": 0,                             # In checkmode 0 for correct, 1 if difference
             "error": []
             },
         "pairingResult" : [                         # Array, 1 element per round
           {
             "round": 3,                             # round number
             "check": True,                          # in check mode, true if equal
             "pairs": [(1,45),(46,2), ...]           # program pairing
             "current": [(1,45),(46,2), ...]         # current pairing from input file
             "analysis": [                            # Tournament analysis array af scorebrackets, may be empty
              {
                "scorelevel": 3                      # internal scorelevel
                "competitors: [6,7,9,12],            # Array of competitor id's
                "pairs": [                           # Array of pair objects
                  {
                    "w": 6,                          # competitor id of white player
                    "b": 19,                         # competitor id of black player, or 0 if PAB
                    "ca": 6,                         # Internal color independed id of player a
                    "cb": 19,                        # Internal color independed id of player b
                    "sa": 5,                         # score level for player a
                    "sb": 5,                         # score level for player b
                    "canmeet": true,                 # If false, then invalid pairing.
                    "psd": 0,                        # difference in scorelevel
                    "played": 0,                     # Number of times these players has met
                    "mode": "T",                     # E: paaired in hetrogenious mode, S: homogenious
                    "quality": [..],                 # Array of c6-c21, q1-q7, see qdefs.py
                    "colorrule": "E.1",                 # Rules used to determine colors
                    "board": 4                       # board number
                     }, { ... }, ...
                    ],
                "downfloaters":  [5, 10, 11],       # Array of downfloated competitors
                "remaining": [13, 14, 15, 16]       # Array of remaining players
                "quality": [..],                    # Array of c6-c21, q1-q7, see qdefs.py
              }, {...}, ...
             ]
             "pairing": [...]                       # Pairing array af scorebrackets, may be empty, same format as analysis
             "competitors": [                       # Array of competitors
              {
                "cid": 6,                           # competitor id
                "pts": 2.0,                         # points so far
                "acc": 2.0,                         # point + accelerated
                "rfp": true,                        # present (ready for pairing)
                "pop": 19,                          # paired opponent
                "pco": "w",                         # paired color
                "hst": {                            # history
                  "val": "19w",                     # current
                  "1": "32w",
                  "2": "23b"
                },
                "num": 2,                           # number of played games
                "rip": 2,                           # number of rounds paired
                "met": {                            # opponents met
                  "val": 2,
                  "1": 32,
                  "2": 23
                },
                "cod": 0,                           # color difference
                "cop": "w0",                        # color preference
                "csq": " wb",                       # color sequence
                "flt": 0,                           # float bitwise 1=df, 2=up, 3=df prev r, 4 uf prev r
                "top": false,                       # topscorer
                "mdp": 0,                           # moved down
                "lmb": -1,                          # limbo in scorelevel
                "scorelevel": 5,                    # scorelevel
              }
             "level2score": [-1.0,0.0, ...]         # Translate scorelevel to acc
            }
          ]
        }
    """

    def __init__(self):
        super().__init__()
        ver = version.version()
        self.resultjson["origin"] =  self.origin = "pairingchecker ver. " + ver["version"]
        self.resultjson["filetype"] =  self.filetype = "Pairing"
        self.resulttype = "pairingResult"
        self.method = {
            "dutch": pairing_dutch,
            "berger": pairing_berger,
            "fideteam": pairing_fideteam
        }

    def read_command_line(self):
        self.parser.add_argument("-a", "--analysis", required=False, action="count", default=0, help="Analysis pairing")
        self.parser.add_argument("-p", "--pairing", required=False, action="count", default=0, help="Do pairing")
        self.parser.add_argument(
            "-m", "--method", required=False, nargs="*", default=[],
            help="dutch | berger | fideteam[-typea | -typeb | -nocolor]",
        )
        self.parser.add_argument("-t", "--top-color", required=False, default=" ", help="Color on top board")
        self.parser.add_argument("-K", "--maxmeets", required=False, default="0", help="The maximum number of meets")
        self.parser.add_argument("-u", "--unpaired", required=False, nargs="*", default=[])
        self.parser.add_argument("-T", "--exchange", required=False, nargs="*", default=[], help="Test mode: exchange pairs")
        self.read_common_command_line(self.origin, True)

    

    def write_text_pairing(self, lines, pairs):
        lines.append(str(len(pairs)))
        for w, b in pairs:
            lines.append(str(w) + " " + str(b))

    def write_text_diff(self, lines, apairs, ppairs):
        eq = True
        head = PHEAD + AHEAD
        for i in range(max(len(apairs), len(ppairs))):
            apair = (str(apairs[i][0]) + "  - " + str(apairs[i][1])) if i < len(apairs) else "-"
            ppair = (str(ppairs[i][0]) + "  - " + str(ppairs[i][1])) if i < len(ppairs) else "-"
            if apair != ppair:
                if head:
                    lines.append(head)
                    head = None
                    eq = False
                apos = apair.find("-")
                a = "         "[apos:] + apair + "                         "[: 15 + apos - len(apair)]
                ppos = ppair.find("-")
                p = "         "[ppos:] + ppair + "                         "[: 15 + ppos - len(ppair)]
                lines.append(p + a)
        return eq



    def format_quality_list(self, analysis, pairing, bno):
        lines = []
        head = "Rule " + (PHEAD if len(pairing) > 0 else "") + (AHEAD if len(analysis) > 0 else "")
        lines.append(head)
        self.qdefsenum = qdefsenum = self.pairingengine.qdefs_enum()
        rangelen = change = self.pairingengine.crosstable.maxquality()
        for i in range(rangelen):  
            label= qdefsenum(i).name
            if label == "QMM" and "QMM" not in self.params["experimental"]:
                continue
            p = str(pairing[bno]["quality"][label] if bno < len(pairing) else "")
            a = str(analysis[bno]["quality"][label] if bno < len(analysis) else "")
            if p != a and i < change:
                change = i
            label = f"{label:<5}"
            plen = len(PHEAD) if len(p) > 0 else 0
            alen = len(AHEAD) if len(a) > 0 else 0
            maxlen = len(AHEAD) - 1
            while len(p) or len(a):
                (ppart, p) = helpers.split_my_line(p, maxlen, ",")
                (apart, a) = helpers.split_my_line(a, maxlen, ",")
                line = label + format("  " + ppart, "<" + str(maxlen + 1)) + format("  " + apart, "<" + str(maxlen + 1))
                label = "     "
                lines.append(line)
        lines.append("")
        return (change, lines)

    def write_text_details(self, lines, analysis, pairing, competitors):
        eq = True
        cr = self.pairingengine.crosstable
        if analysis and pairing:
            alen = sum([len((bracket["pairs"] if bracket is not None and "pairs" in bracket else [])) for bracket in analysis])
            plen = sum([len((bracket["pairs"] if bracket is not None and "pairs" in bracket else [])) for bracket in pairing])
            eq = eq and (alen == plen)
        
        for bno in range(max(len(pairing), len(analysis))):
            allcompetitors = acmps = pcmps = apairs = ppairs = adown = pdown = []
            bsn = {}
            if analysis:
                work = analysis
                if bno < len(analysis):
                    scorelevel = analysis[bno]["scorelevel"]
                    bsn = "bsn-" + str(scorelevel)
                    # print(bsn, analysis[bno]['competitors'])
                    allcompetitors = acmps = sorted(
                        [competitors[c] for c in analysis[bno]["competitors"]], key=lambda s: (-s["scorelevel"], s["cid"])
                    )
                    bsn = analysis[bno].get("bsne", [])
                    apairs = (
                        sorted(analysis[bno]["pairs"], key=lambda c: (c["board"]))
                        if bno < len(analysis) and bno < len(analysis)
                        else []
                    )
                    acomp = pcomp = {c["cid"]: c for c in allcompetitors}
                    aopp = {
                        **{c["w"]: str(c["b"]) + "w" for c in apairs},
                        **{c["b"]: str(c["w"]) + "b" for c in apairs},
                        **{c: "down" for c in analysis[bno]["downfloaters"]},
                    }
                    adown = sorted(
                        [c for c in analysis[bno]["downfloaters"]], key=lambda s: (-pcomp[s]["scorelevel"], pcomp[s]["cid"])
                    )
                else:
                    allcompetitors = acmps = bsn = apairs = adown = []
                    aopp = {}
            if pairing:
                work = pairing
                scorelevel = pairing[bno]["scorelevel"]
                allcompetitors = pcmps = sorted(
                    [competitors[c] for c in pairing[bno]["competitors"]], key=lambda s: (-s["scorelevel"], s["cid"])
                )
                bsn = pairing[bno].get("bsne", [])
                pcomp = {c["cid"]: c for c in allcompetitors}
                ppairs = (
                    sorted(pairing[bno]["pairs"], key=lambda c: (c["board"])) if bno < len(pairing) and bno < len(pairing) else []
                )
                popp = {
                    **{c["w"]: str(c["b"]) + "w" for c in ppairs},
                    **{c["b"]: str(c["w"]) + "b" for c in ppairs},
                    **{c: "down" for c in pairing[bno]["downfloaters"]},
                }
                pdown = sorted([c for c in pairing[bno]["downfloaters"]], key=lambda s: (-pcomp[s]["scorelevel"], pcomp[s]["cid"]))

            if len(acmps) > 0 and len(pcmps) > 0 and [c["cid"] for c in acmps] != [c["cid"] for c in pcmps]:
                aopp = {}
                acmps = None

            df = [" ", "D", "U", "B"]
            if len(allcompetitors) > 0:  # Dont print brackets without competitors
                # print("Scorelevel", work[bno]['scorelevel'])
                scorelevel = work[bno]["scorelevel"]
                scorebracket = str(cr.level2score[scorelevel]) if work[bno] is not None and len(cr.level2score) > scorelevel else "--"
                lines.append(
                    "== Bracket: " + scorebracket + ", scorelevel: " + str(scorelevel) + (", PAB" if work[bno].get("pab", "") else "")
                )
                #         3   4    5    5          5                         2  3  3
                line = "SNO BSN  PTS" + ("    P" if len(pcmps) else "") + ("    A" if acmps else "") + " T CP CD F1 F2"
                l0 = allcompetitors[0]["hst"]
                line += "".join([f"{key:>5}" for key in l0.keys() if isinstance(key, int)])
                lines.append(line)
                colorprefs = defaultdict(int)
                for cmp in allcompetitors:
                    try:
                        line = (
                            f"{cmp['cid']:>3}"
                            + f"{bsn[cmp['cid']] if cmp['cid'] in bsn else '?':>4}"
                            + f"{cmp['acc']:>5}"
                            + (f"{popp[cmp['cid']]:>5}" if len(pcmps) else "")
                            + (f"{aopp[cmp['cid']]:>5}" if acmps and len(acmps) else "")
                            + " "
                            + ("T" if cmp["top"] else " ")
                            + " "
                            + cmp["cop"]
                            + " "
                            + f"{cmp['cod']:>2}"
                            + "  "
                            + df[cmp["flt"] % 4]
                            + "  "
                            + df[(cmp["flt"] // 4) % 4]
                        )
                    except:
                        pass
                        # breakpoint()
                    line += "".join([f"{val:>5}" for key, val in cmp["hst"].items() if isinstance(key, int)])
                    lines.append(line)
                    cop = cmp["cop"].replace("  ", "nc")
                    colorprefs[cop] += 1
                    colorprefs[cop[:1]] += 1
                lines.append("")
                line = "Colors:   "
                lines.append(line)
                for i in range(3):
                    w = "w" + str(i)
                    b = "b" + str(i)
                    line = "      " + w + ": " + f"{colorprefs.get(w, 0):>3}" + "   " + b + ": " + f"{colorprefs.get(b, 0):>3}"
                    lines.append(line)
                line = (
                    "Tot:  "
                    + "wc: "
                    + f"{colorprefs.get('w', 0):>3}"
                    + "   bc: "
                    + f"{colorprefs.get('b', 0):>3}"
                    + "   nc: "
                    + f"{colorprefs.get('n', 0):>3}"
                )
                # print("Col:", colorprefs.get("n", 0),
                #      colorprefs.get("w0", 0),
                #      colorprefs.get("w", 0),
                #      colorprefs.get("b0", 0),
                #      colorprefs.get("b", 0),
                #      analysis[bno]['quality'][qdefs.C6.value],
                #      analysis[bno]['quality'][qdefs.C12.value],
                #      analysis[bno]['quality'][qdefs.C13.value]
                #      )
                lines.append(line)
                lines.append("")

                (change, qlines) = self.format_quality_list(analysis, pairing, bno)
                sno = "tpn" if "TPN" in self.params["experimental"] else "cid"
                line = "Pairs    :    Pairing      BSN        Analysis      BSN    "
                lines.append(line)
                for pno in range(max(len(ppairs), len(apairs))):
                    pp = helpers.format_pair(ppairs[pno], pcomp, bsn, sno) if pno < len(ppairs) else ""
                    ap = helpers.format_pair(apairs[pno], acomp, bsn, sno) if pno < len(apairs) else ""
                    arrow = "       <=======  " if eq else ""
                    eq = eq and (pp == ap)
                    arrow = arrow if not eq else ""
                    line = "          " + f"{pp:>24}" + f"{ap:>24}" + arrow
                    if pno < len(ppairs) and pno < len(apairs) and ppairs[pno]["w"] == apairs[pno]["b"] and ppairs[pno]["b"] == apairs[pno]["w"]:
                        line += f" {ppairs[pno]['colorrule']}"
                    elif arrow and change < self.qdefsenum.IW.value:
                        line += " " + self.qdefsenum(change).name
                    lines.append(line)
                line = "Down     :"
                for pno in range(max(len(pdown), len(adown))):
                    pp = helpers.format_down(pdown[pno], pcomp, bsn) if pno < len(pdown) else ""
                    ap = helpers.format_down(adown[pno], acomp, bsn) if pno < len(adown) else ""
                    eq = eq and (pp == ap)
                    line += f"{pp:>24}" + f"{ap:>24}"
                    lines.append(line)
                    line = "          "
                lines.append("")
                lines += qlines

        return eq


    def write_text_file(self, f, result, delimiter, decimal_point):
        lines = []
        eq = True
        if not self.docheck:
            self.write_text_pairing(lines, result["pairs"])
            lines.append("")
        else:
            for rndpairing in result["roundpairing"]:
                analysis = rndpairing.get("analysis", {})
                pairing = rndpairing.get("pairing", {})
                competitors = rndpairing.get("competitors", [])

                lines.append("================= Round #" + str(rndpairing["round"]) + " =================")
                if self.doanalysis or self.dopairing:
                    eq = eq and self.write_text_details(lines, analysis, pairing, competitors)
                else:
                    eq = self.write_text_diff(lines, rndpairing["current"], rndpairing["pairs"]) and eq
                lines.append("")
        if self.params["check"] and ((self.dopairing > 0) == (self.doanalysis > 0)):
            lines.append(f"Check: {eq}")
        f.writelines(line + "\n" for line in lines)
        # if not eq: breakpoint()
        return eq

    def write_trf_file(self, result, tournamentno, verbose):
        trf = trf2json()
        event = self.chessfile.chessjson["event"]
        tournament = self.chessfile.get_tournament(self.tournamentno)
        if "pairs" in result and result["pairs"] is not None and len(result["pairs"]) > 0:
            # update game list with new pairing
            tournament["currentRound"] = result["round"]
            for (w, b) in result["pairs"]:
                white = {"cid": w, "result": "A" if b > 0 else "P"}
                black = {"cid": b, "result": "A"} if b > 0 else None
                tournament["gameList"].append({"round": result["round"], "played": True, "white": white, "black": black})

            # update game scores
            competitors = {comp["cid"]: comp for comp in tournament["competitors"]}
            for game in [game for game in tournament["gameList"] if game["round"] == result["round"]]:
                for color in ["white", "black"]:
                    if game[color] is not None and game[color]["cid"] > 0:
                        gamepoints = tournament["scoreSystem"]["game"][game[color]["result"]]
                        while isinstance(gamepoints, str) and gamepoints in tournament["scoreSystem"]["game"]:
                            gamepoints = tournament["scoreSystem"]["game"][gamepoints]
                        competitors[game[color]["cid"]]["gamePoints"] += gamepoints

        data = trf.output_file(self.chessfile.chessjson["event"], tournamentno, verbose)
        return data



    def compute_pairs(self, pairing):
        # pairing = analysis if pairing is None or len(pairing) == 0 else pairing
        pairs = []
        for bracket in pairing:
            if bracket is not None and "pairs" in bracket:
                for pair in bracket["pairs"]:
                    pairs.append(pair)
        pairs = [(pair["w"], pair["b"]) for pair in sorted(pairs, key=lambda c: (c["board"]))]
        return pairs

    def compute_pairing(self, chessfile, pairingengine, params):
        # print('PARAMS', params)
        chessfile = self.chessfile
        self.pairingengine = pairingengine
        analysis = pairing = []
        complete = True
        acompetitors = pcompetitors = {}
        if self.doanalysis or (self.docheck and not self.doanalysis and not self.dopairing):
            analysis = pairingengine.compute_pairing(True, self.doanalysis)
            acompetitors = sorted(
                #[{key: value for (key, value) in c.items() if key != "opp"} for c in pairingengine.crosstable.competitors],
                pairingengine.crosstable.competitors,
                key=lambda c: (c["cid"]),
            )

        if self.dopairing or (self.docheck and not self.doanalysis and not self.dopairing):
            try:
                pairing = pairingengine.compute_pairing(False, self.dopairing)
            except GacruxNoLegalPairing:
                # No prescribed round; the declared analysis above still applies.
                complete = False
            pcompetitors = sorted(
                #[{key: value for (key, value) in c.items() if key != "opp"} for c in pairingengine.crosstable.crosstable],
                pairingengine.crosstable.competitors,
                key=lambda c: (c["cid"]),
            )
        result = {
            "round": pairingengine.rnd,
            "pairs": self.compute_pairs(pairing),
            "current": self.compute_pairs(analysis),
        }
        if self.docheck:
            result["check"] = complete and result["pairs"] == result["current"]
            result["pairing"] = pairing
            result["analysis"] = analysis
            result["competitors"] = pcompetitors if len(pcompetitors) >= len(acompetitors) else acompetitors
            result["level2score"] = pairingengine.crosstable.level2score,
 
        # chessfile.chessjson["status"]["code"] = 1
        return result

    def fakerank(self, tm, trans, roundpairing):
        for competitor in tm["competitors"]:
            competitor["cid"] = trans[competitor["cid"]]
        for game in tm["gameList"]:
            game["white"] = trans[game["white"]]
            game["black"] = trans[game["black"]]
        tm["competitors"] = sorted(tm["competitors"], key=lambda c: c["cid"])
        for cround in roundpairing:
            for key in ["pairs", "current"]:
                for pair in cround[key]:
                    pair = (trans[pair[0]], trans[pair[1]])
            for key in ["analysis", "pairing"]:
                for level in cround[key]:
                    for pair in level["pairs"]:
                        pair["w"] = trans[pair["w"]]
                        pair["b"] = trans[pair["b"]] if pair["b"] > 0 else 0
                        pair["ca"] = trans[pair["ca"]]
                        pair["cb"] = trans[pair["cb"]] if pair["cb"] > 0 else 0 

    # For test purposes, exchange pairs in the input file, to check if checker can find a better pairing. 
    # Format of exchange is list of strings "a-b" where a and b are competitor id's. Example: -T 1-2 3-4
    def add_exchanges(self, tournament, currentround, exchanges):
        pairs = []
        players = set()
        errtxt = "Illegal exchange format: " + ", ".join(exchanges) 
        try:
            for exchange in exchanges:
                a, b = exchange.split("-")
                a = int(a)
                b = int(b)
                pairs.append((a, b))
                players.add(a)
                players.add(b)
            cid = self.chessfile.get_result_cid
            affected = [pair for pair in tournament["gameList"] if pair["round"] == currentround and (cid(pair, "white") in players or cid(pair, "black") in players)]
            oplayers = set()
            for pair in affected:
                oplayers.add(cid(pair, "white"))
                oplayers.add(cid(pair, "black"))
            if players != oplayers:
                errtxt = "Illegal exchange format: " + str(players) + " != " + str(oplayers)
                raise
            for i, pair in enumerate(affected):
                pair["white"]["cid"] = pairs[i][0]
                pair["black"]["cid"] = pairs[i][1]
        except:
            self.error(410, errtxt)

    def do_checker(self):
        params = self.params
        chessfile = self.chessfile
        if params["check"]:
            chessfile.result = {
                "rules": "", 
                "roundpairing": [],
            }
        else:            
            chessfile.result = {
                "rules": "", 
                "round": 0,
                "pairs": None,
                "roundpairing": []
            }
        if chessfile.get_status() == 0:
            if self.tournamentno > 0:
                tournament = chessfile.get_tournament(self.tournamentno)
                currentround = tournament["currentRound"]
                numrounds = max(tournament.get("numRounds", 0), tournament.get("currentRound", 0))
                firstround = lastround = params.get("current_round", -1)
                if len(self.params["exchange"]):
                    self.add_exchanges(tournament, firstround, self.params["exchange"])
                self.dopairing = params.get("pairing", True)
                self.docheck = params.get("check", False)
                self.doanalysis = params.get("analysis", False)
                if firstround == -1:
                    if self.dopairing:
                        firstround = lastround = currentround + 1
                    if self.doanalysis:
                        firstround = lastround = currentround
                    if self.docheck:
                        firstround = 1
                        lastround = currentround
                if lastround > numrounds:
                    self.error(504, "Number of rounds = " + str(numrounds) + ", can't pair round " + str(lastround))
                pairingSystems = list(set(tournament["pairingSystem"]) & set(self.method))
                if len(pairingSystems) != 1:
                    self.error(510, "Method '" + "-".join(tournament["pairingSystem"]) + "' not implemented")
                    #self.error(504, "Number of rounds = " + str(numrounds) + ", can't pair round " + str(lastround))
                pairingSystem = pairingSystems[0]
                if "experimental" in params and "fakerank" in params["experimental"]:
                    fwd = [0]*(len(tournament["competitors"])+1)
                    inv = [0]*(len(tournament["competitors"])+1)
                    for i, c in enumerate(tournament["competitors"]):
                        fwd[c["cid"]] = c["rank"]
                        inv[c["rank"]] = c["cid"]
                    self.fakerank(tournament, fwd, [])
                for rnd in range(firstround, min(numrounds, lastround) + 1):
                    unpaired = [helpers.parse_int(u) for u in params.get("unpaired", [])]
                    if len(unpaired) > 0:
                        for c in tournament["competitors"]:
                            if c["cid"] in unpaired:
                                c["present"] = False
                    pairingEngine = self.method[pairingSystem]
                    cpairing = pairingEngine(tournament, rnd, params)
                    chessfile.result["rules"] = cpairing.rules
                    result = self.compute_pairing(chessfile, cpairing, params)
                    chessfile.result["roundpairing"].append(result)
                if "fakerank" in params["experimental"]:
                    self.fakerank(tournament, inv, chessfile.result["roundpairing"])
                    # print("================= Round #" + str(rnd )+ " =================")


    def apply_result(self):
        params = self.params
        chessfile = self.chessfile
        if chessfile.get_status() == 0:
            if params["check"]:
                ok = all([rndpairing["check"] for rndpairing in chessfile.result["roundpairing"]])
                # -a computes the declared pairing and -p the engine's own, so exactly one
                # of them asks for one side of the comparison and leaves the other empty.
                # There is then no difference to find, and the verdict is suppressed rather
                # than reported as a mismatch. write_text_file decides whether to print its
                # "Check:" line from the same test, written the same way, in the opposite
                # sense.
                ok = ok or ((self.dopairing > 0) != (self.doanalysis > 0))
                chessfile.result["check"] = ok
                self.resultjson["status"]["code"] = 0 if ok else 1
            else: 
                pairs = "pairs" if self.dopairing else "current"
                ok = len(chessfile.result["roundpairing"][0][pairs]) > 0
                self.resultjson["status"]["code"] = 0 if ok else 2  
                chessfile.result["pairs"] =  chessfile.result["roundpairing"][0][pairs]
                chessfile.result["round"] =  chessfile.result["roundpairing"][0]["round"]
                chessfile.result.pop("roundpairing")
                




# tournament.export_trf(params)


# run program
if __name__ == "__main__":
    # sys.set_int_max_str_digits(12000)
    start_time = time.time()
    pch = pairingchecker()
    code = pch.common_main()
    if "time" in pch.params["experimental"]:
        elapsed = (time.time() - start_time)
        print(f"--- {elapsed:.3f} seconds ---")
