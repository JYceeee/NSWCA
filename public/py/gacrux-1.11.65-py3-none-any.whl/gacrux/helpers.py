﻿# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 13:57:55 2023
@author: Otto Milvang, sjakk@milvang.no
"""
import collections.abc
import decimal
import json
import sys
import decimal


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        #if isinstance(o, EnumType): 
        #    return [str(q.name) for q in o]
               
        if isinstance(o, decimal.Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)


# ==============================
#
#  Helpers


#  Dict access


def safe(dict_list, acc_list, default=None):
    for d in dict_list:
        val = d
        for a in acc_list:
            if val is not None:
                val = val.get(a)
        if val is not None:
            return val
    return default

def deep_update(d, u):
    for k, v in u.items():
        if isinstance(v, collections.abc.Mapping):
            d[k] = deep_update(d.get(k, {}), v)
        else:
            d[k] = v
    return d

#  Parse


def parse_date(date):
    datetime = date.split(" ", 1)
    dateparts = datetime[0].split(".")
    if len(dateparts) == 3:
        if len(dateparts[0]) == 4:
            return date.replace(".", "-")
        # datetime, not dateparts: the time is the second half of the split on " ",
        # and dateparts is already known to hold three fields here, so asking it for
        # two could never be true and the time was dropped.
        if len(datetime) == 2:
            return dateparts[2] + "-" + dateparts[1] + "-" + dateparts[0] + " " + datetime[1]
        return dateparts[2] + "-" + dateparts[1] + "-" + dateparts[0]
    dateparts = datetime[0].split("/")
    if len(dateparts) == 3:
        if len(dateparts[0]) == 4:
            return date.replace("/", "-")
        return "20" + date.replace("/", "-")
    return date


def parse_minutes(time):
    hms = time.split(":")
    if len(hms) != 3:
        return 0
    return int(hms[0]) * 60 + int(hms[1])


def parse_seconds(time):
    hms = time.split(":")
    if len(hms) != 3:
        return 0
    return int(hms[0]) * 3600 + int(hms[1]) * 60 + int(hms[2])


def parse_int(txt):
    txt = txt.strip()
    if len(txt) == 0:
        return 0
    return int(txt)


def parse_float(txt):
    txt = txt.strip()
    if len(txt) == 0:
        return decimal.Decimal("0.0")
    txt = txt.replace(",", ".")
    return decimal.Decimal(txt)


def to_base36(num):
    b36 = min(abs(int(num * decimal.Decimal("2.0"))), 35)
    return "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"[b36]


def from_base36(s):
    if s == "":
        return 0
    b36 = int(s, 36)
    return b36


def split_my_line(line, maxlen, delimiter):
    if len(line) < maxlen:
        return (line, "")
    pos = line[:maxlen].rfind(delimiter)
    return (line[: pos + 1], line[pos + 1:])


# return -1 if different
# return 1 if equal
# return 0 if dont know
def is_equal(txt, struct1, struct2):
    if not (txt in struct1 and txt in struct2):
        return 0
    val1 = struct1[txt]
    val2 = struct2[txt]
    if (type(val1) is type(0) and val1 == 0) or (type(val2) is type(0) and val2 == 0):
        return 0
    if (type(val1) is type("") and val1 == "") or (type(val2) is type("") and val2 == ""):
        return 0
    if val1 == val2:
        return 1
    else:
        return -1


#
# Function: getFileFormat
# Returns a file format.
#
# Parameters:
#     $filename - Filename of tournament file
#


def getFileFormat(filename):
    parts = filename.split(".")
    lastp = parts[-1].lower()
    # retval = ""
    # match lastp:
    if lastp == "jch" or lastp == "json":
        return "JSON"
    if lastp == "txt" or lastp == "trf" or  lastp == "trfx":
        return "TRF"
    if lastp == "trx":
        return "TS"
    return "JSON"


def sortxval(x):
    return x["val"]


def sortnum(x):
    return x["num"]


def subtract_lowest(x, y):
    minval = min(x, y)
    return (x - minval, y - minval)


# =================
#
# format
#
#


def format_pair(c, pcmps, bsn, sno):
    a = c["w"]
    b = c["b"]
    sa = ("    " + str(pcmps[a][sno]))[-4:]
    ba = ("    " + str(bsn[pcmps[a]["cid"]]))[-4:] if pcmps[a]["cid"] in bsn else "  ?"
    if b not in pcmps:
        # The pairing-allocated bye: both engines write it as a pair against competitor
        # 0, the dummy, which is not a competitor and is not in the bracket's own list.
        # Printed with the opponent's side left blank, the way format_down prints a
        # downfloater, rather than indexed for a name that is not there.
        return sa + " - " + "    " + " (" + ba + " - " + "    " + ")"
    sb = (str(pcmps[b][sno]) + "   ")[0:4]
    bb = ((str(bsn[pcmps[b]["cid"]]) + "    ")[:4]) if pcmps[b]["cid"] in bsn else "  ?"
    return sa + " - " + sb + " (" + ba + " - " + bb + ")"


def format_down(c, pcmps, bsn):
    sa = ("    " + str(c))[-4:]
    sb = "    "
    ba = ("    " + str(bsn[pcmps[c]["cid"]]))[-4:] if pcmps[c]["cid"] in bsn else "  ?"
    bb = "    "
    return sa + " - " + sb + " (" + ba + " - " + bb + ")"


def format_name(profile):
    if "fideName" in profile and profile["fideName"].find(",") > 0:
        # if "fideName" in profile and len(profile["fideName"]) > 0:
        name = profile["fideName"]
    elif len(profile["lastName"]) > 0 and len(profile["firstName"]) > 0:
        name = profile["lastName"] + ", " + profile["firstName"]
    elif len(profile["lastName"]) > 0:
        name = profile["lastName"]
    elif len(profile["firstName"]) > 0:
        name = profile["firstName"]
    else:
        name = ""  # f"Player {profile['id']:4}"
    return name


def format_datetime(datetime, year="YY"):
    start = 4 - len(year)
    if len(datetime) == 10 and datetime[4] == "-" and datetime[7] == "-":
        return datetime[start:4] + "/" + datetime[5:7] + "/" + datetime[8:10]
    return datetime

def ascii_name(name):
    tr = {  "À": "A", "Á": "A", "Â": "A", "Ã": "A", "Ä": "A", "Å": "A", "Æ": "A",
            "Ç": "C",
            "È": "E", "É": "E", "Ê": "E", "Ë": "E",
            "Ì": "I", "Í": "I", "Î": "I", "Ï": "I",
            "Ð": "T",
            "Ñ": "N", 
            "Ò": "O", "Ó": "O", "Ô": "O", "Õ": "O", "Ö":  "O", "Ø": "O",
        	"Ù": "U", "Ú": "U", "Û": "U", "Ü": "U", 
            "Ý": "Y", 
            "ß": "s",
            "à": "a", "á": "a", "â": "a", "ã": "a", "ä": "a", "å": "a", "æ": "a", 
            "ç": "c",
            "è": "e", "é": "e", "ê": "e", "ë": "e", 
            "ì": "i", "í": "i", "î": "i", "ï": "i", 
            "ð": "t",	
            "ñ": "n",
            "ò": "o", "ó": "o", "ô": "o", "õ": "o", "ö": "o", "ø": "o", 
            "ù": "u", "ú": "u", "û": "u", "ü": "u", "ý": "y", "ÿ": "y",
        }
    ca = [tr.get(c, c) for c in list(name)]
    str =  "".join(ca)
    return(str)



# =================
#
# rating selector
#
#


def rating_fide(fide, nrs):
    return fide


def rating_nro(fide, nrs):
    return nrs


def rating_fidon(fide, nrs):
    return fide if fide is not None else nrs


def rating_nidof(fide, nrs):
    return nrs if nrs is not None else fide


def rating_hbfn(fide, nrs):
    if fide is None and nrs is None:
        return None
    if fide is None:
        return nrs
    if nrs is None:
        return fide
    if fide["rating"] > nrs["rating"]:
        return fide
    if nrs["rating"] > fide["rating"]:
        return nrs
    return fide


def rating_lbfn(fide, nrs):
    if fide is None and nrs is None:
        return None
    if fide is None:
        return nrs
    if nrs is None:
        return fide
    if fide["rating"] < nrs["rating"]:
        return fide
    if nrs["rating"] < fide["rating"]:
        return nrs
    return fide


def rating_other(fide, nrs):
    return 0


def query_yes_no(question, default="yes"):
    """Ask a yes/no question via raw_input() and return their answer.

    "question" is a string that is presented to the user.
    "default" is the presumed answer if the user just hits <Enter>.
            It must be "yes" (the default), "no" or None (meaning
            an answer is required of the user).

    The "answer" return value is True for "yes" or False for "no".
    """
    valid = {"yes": True, "y": True, "ye": True, "no": False, "n": False}
    if default is None:
        prompt = " [y/n] "
    elif default == "yes":
        prompt = " [Y/n] "
    elif default == "no":
        prompt = " [y/N] "
    else:
        raise ValueError("invalid default answer: '%s'" % default)

    while True:
        sys.stdout.write(question + prompt)
        choice = input().lower()
        if default is not None and choice == "":
            return valid[default]
        elif choice in valid:
            return valid[choice]
        else:
            sys.stdout.write("Please respond with 'yes' or 'no' " "(or 'y' or 'n').\n")


# =================
#
# Json output
#
#



def xxjson_input(file, json, obj):
    if isinstance(file, str):
        f = sys.stdin if file == "-" else open(file, "r")
    else:
        f = file
    jsonout = json.dumps(obj, indent=2, cls=DecimalEncoder) # default=decimal_serializer)
    f.write(jsonout)
    f.write(jsonout.replace('"_jpre_', "").replace('_jpost_"', "") + "\n")
    if isinstance(file, str) and file != "-":
        f.close()


def json_output(file, obj):
    if isinstance(file, str):
        f = sys.stdout if file == "-" else open(file, "w")
    else:
        f = file
    jsonout = json.dumps(obj, indent=2, cls=DecimalEncoder) # default=decimal_serializer)
    f.write(jsonout)
    if isinstance(file, str) and file != "-":
        f.close()


def txt_output(file, obj):
    if isinstance(file, str):
        f = sys.stdout if file == "-" else open(file, "w")
    else:
        f = file
    f.write(obj)
    if isinstance(file, str) and file != "-":
        f.close()
